<?php
require_once '../classes/User.php';
$userObj = new User();

if ($userObj->isLoggedIn()) {
    if ($_SESSION['role'] == 'admin') {
        header('Location: ../admin/dashboard.php');
    } elseif ($_SESSION['role'] == 'producer') {
        header('Location: ../producer/dashboard.php');
    } else {
        header('Location: index.php');
    }
    exit();
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    $result = $userObj->login($username, $password);

    if ($result['success']) {
        if ($result['role'] == 'admin') {
            header('Location: ../admin/dashboard.php');
        } elseif ($result['role'] == 'producer') {
            header('Location: ../producer/dashboard.php');
        } else {
            header('Location: index.php');
        }
        exit();
    } else {
        $error = $result['message'];
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="default">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — Greenfield Local Hub</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    
</head>
<body>

<a class="skip-link" href="#main-content">Skip to main content</a>

<!-- Accessibility toolbar -->
<div class="a11y-toolbar" role="toolbar" aria-label="Accessibility options">
    <div class="inner">
        <span class="a11y-label" aria-hidden="true"><i class="fas fa-universal-access"></i> Accessibility:</span>
        <button class="a11y-btn" id="btn-theme-dark"  aria-pressed="false" title="Toggle dark mode"><i class="fas fa-moon" aria-hidden="true"></i> Dark</button>
        <div class="a11y-divider" role="separator" aria-hidden="true"></div>
        <button class="a11y-btn" id="btn-theme-high"  aria-pressed="false" title="High contrast"><i class="fas fa-adjust" aria-hidden="true"></i> High Contrast</button>
        <button class="a11y-btn" id="btn-theme-low"   aria-pressed="false" title="Low contrast"><i class="fas fa-circle-half-stroke" aria-hidden="true"></i> Low Contrast</button>
        <div class="a11y-divider" role="separator" aria-hidden="true"></div>
        <button class="a11y-btn" id="btn-font-large"  aria-pressed="false" title="Large text"><i class="fas fa-text-height" aria-hidden="true"></i> Large Text</button>
        <button class="a11y-btn" id="btn-reset"        title="Reset appearance"><i class="fas fa-rotate-left" aria-hidden="true"></i> Reset</button>
    </div>
</div>

<!-- Top nav -->
<nav class="top-nav" aria-label="Site navigation">
    <a class="brand-link" href="index.php" aria-label="Greenfield Local Hub home">
        <div class="brand-leaf" aria-hidden="true"><i class="fas fa-seedling"></i></div>
        Greenfield Local Hub
    </a>
    <a class="back-link" href="index.php">
        <i class="fas fa-arrow-left" aria-hidden="true"></i> Back to Home
    </a>
</nav>

<!-- Main content -->
<main id="main-content" class="page-body">
    <div class="login-card" role="region" aria-label="Login form">

        <p class="card-eyebrow"><i class="fas fa-seedling" aria-hidden="true"></i> Welcome back</p>
        <h1 class="card-title">Sign in to your account</h1>
        <p class="card-subtitle">Access your orders, favourites, and farm-fresh products.</p>

        <?php if ($error): ?>
        <div class="error-box" role="alert" aria-live="assertive">
            <i class="fas fa-circle-exclamation" aria-hidden="true"></i>
            <span><?php echo htmlspecialchars($error); ?></span>
        </div>
        <?php endif; ?>

        <form method="POST" id="loginForm" novalidate>

            <div class="field-group">
                <label class="field-label" for="username">Username or Email</label>
                <div class="field-wrap">
                    <input
                        class="field-input"
                        type="text"
                        id="username"
                        name="username"
                        autocomplete="username"
                        placeholder="Enter your username or email"
                        required
                        value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>"
                        aria-required="true"
                        aria-describedby="username-hint"
                    >
                    <i class="fas fa-user field-icon" aria-hidden="true"></i>
                </div>
            </div>

            <div class="field-group">
                <label class="field-label" for="password">Password</label>
                <div class="field-wrap">
                    <input
                        class="field-input has-toggle"
                        type="password"
                        id="password"
                        name="password"
                        autocomplete="current-password"
                        placeholder="Enter your password"
                        required
                        aria-required="true"
                    >
                    <i class="fas fa-lock field-icon" aria-hidden="true"></i>
                    <button type="button" class="pw-toggle" id="pwToggle"
                            aria-label="Show password" aria-pressed="false">
                        <i class="fas fa-eye" aria-hidden="true"></i>
                    </button>
                </div>
            </div>

            <button type="submit" class="btn-submit" id="submitBtn">
                <i class="fas fa-right-to-bracket" aria-hidden="true"></i>
                <span id="submitLabel">Sign In</span>
            </button>
        </form>

        <div class="form-divider" aria-hidden="true">or</div>

        <div class="card-footer-links">
            <p>Don't have an account? <a href="register.php">Create one free</a></p>
        </div>
    </div>
</main>

<footer class="page-footer" role="contentinfo">
    <p>&copy; 2024 <a href="index.php">Greenfield Local Hub</a>. All rights reserved.</p>
</footer>

<script>
(function () {
    'use strict';

    /* ---- Accessibility preferences (shared with index.php) ---- */
    const html      = document.documentElement;
    const THEME_KEY = 'glh_theme';
    const FONT_KEY  = 'glh_font';

    function applyTheme(theme) {
        html.setAttribute('data-theme', theme || 'default');
        ['dark','high','low'].forEach(function(t) {
            var btn = document.getElementById('btn-theme-' + t);
            if (btn) { btn.classList.remove('active'); btn.setAttribute('aria-pressed','false'); }
        });
        var map = { dark: 'btn-theme-dark', 'high-contrast': 'btn-theme-high', 'low-contrast': 'btn-theme-low' };
        if (map[theme]) {
            var el = document.getElementById(map[theme]);
            if (el) { el.classList.add('active'); el.setAttribute('aria-pressed','true'); }
        }
        localStorage.setItem(THEME_KEY, theme || 'default');
    }

    function toggleTheme(theme) {
        applyTheme(html.getAttribute('data-theme') === theme ? 'default' : theme);
    }

    function applyFontSize(size) {
        html.setAttribute('data-font-size', size || 'normal');
        var btn = document.getElementById('btn-font-large');
        var isLarge = size === 'large';
        btn.classList.toggle('active', isLarge);
        btn.setAttribute('aria-pressed', isLarge ? 'true' : 'false');
        localStorage.setItem(FONT_KEY, size || 'normal');
    }

    function toggleFont() {
        applyFontSize(html.getAttribute('data-font-size') === 'large' ? 'normal' : 'large');
    }

    // Restore saved prefs immediately (before paint)
    var savedTheme = localStorage.getItem(THEME_KEY);
    var savedFont  = localStorage.getItem(FONT_KEY);
    if (savedTheme) applyTheme(savedTheme);
    if (savedFont)  applyFontSize(savedFont);

    document.getElementById('btn-theme-dark').addEventListener('click', function(){ toggleTheme('dark'); });
    document.getElementById('btn-theme-high').addEventListener('click', function(){ toggleTheme('high-contrast'); });
    document.getElementById('btn-theme-low').addEventListener('click',  function(){ toggleTheme('low-contrast'); });
    document.getElementById('btn-font-large').addEventListener('click', toggleFont);
    document.getElementById('btn-reset').addEventListener('click', function(){
        applyTheme('default'); applyFontSize('normal');
    });

    /* ---- Password visibility toggle ---- */
    var pwInput  = document.getElementById('password');
    var pwToggle = document.getElementById('pwToggle');
    var pwIcon   = pwToggle.querySelector('i');

    pwToggle.addEventListener('click', function() {
        var isHidden = pwInput.type === 'password';
        pwInput.type = isHidden ? 'text' : 'password';
        pwIcon.className = isHidden ? 'fas fa-eye-slash' : 'fas fa-eye';
        pwToggle.setAttribute('aria-label', isHidden ? 'Hide password' : 'Show password');
        pwToggle.setAttribute('aria-pressed', isHidden ? 'true' : 'false');
        pwInput.focus();
    });

    /* ---- Form submission with loading state ---- */
    document.getElementById('loginForm').addEventListener('submit', function() {
        var btn   = document.getElementById('submitBtn');
        var label = document.getElementById('submitLabel');
        btn.disabled = true;
        label.textContent = 'Signing in…';
        btn.querySelector('i').className = 'fas fa-spinner fa-spin';
        // Let the native POST proceed — no AJAX (avoids the broken AJAX logic in original)
    });
})();
</script>
</body>
</html>