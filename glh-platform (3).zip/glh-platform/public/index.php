<?php
require_once '../classes/Product.php';
require_once '../classes/User.php';
require_once '../classes/ContentManager.php';
require_once '../classes/CurrencyManager.php';

$productObj = new Product();
$userObj = new User();
$contentManager = new ContentManager();
$currencyManager = new CurrencyManager();

$products = $productObj->getAllProducts();
$currentCurrency = $currencyManager->getCurrentCurrency();
?>
<!DOCTYPE html>
<html lang="en" data-theme="default">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $contentManager->get('site_title', 'Greenfield Local Hub'); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">

    <!-- Libs -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    
</head>
<body>

<!-- Skip to main content (keyboard accessibility) -->
<a class="skip-link" href="#main-content">Skip to main content</a>

<?php if ($contentManager->get('promo_banner')): ?>
<div class="promo-banner" role="banner" aria-label="Promotional announcement">
    <i class="fas fa-tag" aria-hidden="true"></i>
    <?php echo $contentManager->render('promo_banner'); ?>
</div>
<?php endif; ?>

<!-- ===================== ACCESSIBILITY TOOLBAR ===================== -->
<div class="a11y-toolbar" role="toolbar" aria-label="Accessibility options">
    <div class="container">
        <span class="a11y-label" aria-hidden="true"><i class="fas fa-universal-access"></i> Accessibility:</span>

        <button class="a11y-btn" id="btn-theme-dark" aria-pressed="false" title="Toggle dark mode">
            <i class="fas fa-moon" aria-hidden="true"></i> Dark
        </button>
        <div class="a11y-divider" role="separator" aria-hidden="true"></div>
        <button class="a11y-btn" id="btn-theme-high" aria-pressed="false" title="High contrast mode">
            <i class="fas fa-adjust" aria-hidden="true"></i> High Contrast
        </button>
        <button class="a11y-btn" id="btn-theme-low" aria-pressed="false" title="Low contrast mode">
            <i class="fas fa-circle-half-stroke" aria-hidden="true"></i> Low Contrast
        </button>
        <div class="a11y-divider" role="separator" aria-hidden="true"></div>
        <button class="a11y-btn" id="btn-font-large" aria-pressed="false" title="Toggle large text">
            <i class="fas fa-text-height" aria-hidden="true"></i> Large Text
        </button>
        <button class="a11y-btn" id="btn-reset" title="Reset to default appearance">
            <i class="fas fa-rotate-left" aria-hidden="true"></i> Reset
        </button>
    </div>
</div>

<!-- ===================== NAVBAR ===================== -->
<nav class="navbar navbar-expand-lg" aria-label="Main navigation">
    <div class="container">
        <a class="navbar-brand" href="index.php" aria-label="Greenfield Local Hub home">
            <div class="brand-leaf" aria-hidden="true"><i class="fas fa-seedling"></i></div>
            <?php echo htmlspecialchars($contentManager->get('site_title', 'Greenfield Local Hub')); ?>
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarNav" aria-controls="navbarNav"
                aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto align-items-center" role="list">
                <li class="nav-item" role="listitem">
                    <a class="nav-link" href="index.php" aria-current="page">Home</a>
                </li>
                <li class="nav-item" role="listitem">
                    <a class="nav-link" href="products.php">Products</a>
                </li>

                <?php if ($userObj->isLoggedIn()): ?>
                    <?php if ($_SESSION['role'] == 'customer'): ?>
                        <li class="nav-item" role="listitem">
                            <a class="nav-link" href="order-history.php">My Orders</a>
                        </li>
                        <li class="nav-item" role="listitem">
                            <a class="nav-link cart-wrapper" href="cart.php" aria-label="Shopping cart">
                                <i class="fas fa-shopping-cart" aria-hidden="true"></i> Cart
                                <span id="cartCount" class="cart-badge" aria-live="polite" aria-label="0 items in cart">0</span>
                            </a>
                        </li>
                    <?php elseif ($_SESSION['role'] == 'producer'): ?>
                        <li class="nav-item" role="listitem">
                            <a class="nav-link" href="../producer/dashboard.php">Dashboard</a>
                        </li>
                    <?php elseif ($_SESSION['role'] == 'admin'): ?>
                        <li class="nav-item" role="listitem">
                            <a class="nav-link" href="../admin/dashboard.php">Admin Panel</a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item" role="listitem">
                        <a class="nav-link" href="logout.php">
                            <i class="fas fa-sign-out-alt" aria-hidden="true"></i>
                            Logout <span class="text-accent">(<?php echo htmlspecialchars($_SESSION['username']); ?>)</span>
                        </a>
                    </li>
                <?php else: ?>
                    <li class="nav-item" role="listitem">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>
                    <li class="nav-item" role="listitem">
                        <a class="nav-link" href="register.php">Register</a>
                    </li>
                <?php endif; ?>

                <!-- Currency switcher -->
                <li class="nav-item dropdown" role="listitem">
                    <button class="nav-link dropdown-toggle btn btn-link border-0"
                            id="currencyDropdown" aria-haspopup="true" aria-expanded="false"
                            data-bs-toggle="dropdown"
                            aria-label="Select currency: <?php echo htmlspecialchars($currentCurrency['currency_code']); ?>">
                        <?php echo htmlspecialchars($currentCurrency['currency_symbol']); ?>
                        <?php echo htmlspecialchars($currentCurrency['currency_code']); ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="currencyDropdown">
                        <?php foreach ($currencyManager->getAllCurrencies() as $currency): ?>
                            <li>
                                <button class="dropdown-item currency-option"
                                        data-currency="<?php echo htmlspecialchars($currency['currency_code']); ?>">
                                    <?php echo htmlspecialchars($currency['currency_symbol']); ?>
                                    <?php echo htmlspecialchars($currency['currency_code']); ?> –
                                    <?php echo htmlspecialchars($currency['currency_name']); ?>
                                </button>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- ===================== HERO ===================== -->
<main id="main-content">
<section class="hero-section" aria-label="Welcome banner">
    <div class="hero-bg" aria-hidden="true"></div>
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-7 hero-content">
                <h1>
                    <?php
                    $heroTitle = $contentManager->get('hero_title', 'Fresh from <span>Local Farms</span>');
                    echo $heroTitle;
                    ?>
                </h1>
                <p><?php echo htmlspecialchars($contentManager->get('hero_subtitle', 'Support local farmers and get the freshest produce delivered to your doorstep. Farm to table, every single day.')); ?></p>
                <div class="hero-cta d-flex flex-wrap gap-3">
                    <a href="products.php" class="btn-hero-primary">
                        <i class="fas fa-leaf" aria-hidden="true"></i> Shop Now
                    </a>
                    <a href="register.php" class="btn-hero-outline">
                        <i class="fas fa-user-plus" aria-hidden="true"></i> Join Community
                    </a>
                </div>
                <div class="hero-stats" aria-label="Platform highlights">
                    <div class="stat-item">
                        <span class="stat-num">200+</span>
                        <span class="stat-label">Local Farmers</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-num">1,400+</span>
                        <span class="stat-label">Products</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-num">24h</span>
                        <span class="stat-label">Fresh Delivery</span>
                    </div>
                </div>
            </div>
            <div class="col-lg-5 hero-visual d-none d-lg-flex" aria-hidden="true">
                <div class="hero-badge-float">
                    <i class="fas fa-seedling"></i>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- WHY US STRIP -->
<section class="why-strip" aria-labelledby="why-heading">
    <div class="container">
        <h2 id="why-heading" class="visually-hidden">Why choose Greenfield</h2>
        <div class="row g-3">
            <div class="col-6 col-md-3">
                <div class="why-card">
                    <div class="icon-wrap" aria-hidden="true"><i class="fas fa-tractor"></i></div>
                    <h5>Farm Direct</h5>
                    <p>Straight from verified local farms to your basket.</p>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="why-card">
                    <div class="icon-wrap" aria-hidden="true"><i class="fas fa-award"></i></div>
                    <h5>Quality Assured</h5>
                    <p>Every product meets our freshness standards.</p>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="why-card">
                    <div class="icon-wrap" aria-hidden="true"><i class="fas fa-truck"></i></div>
                    <h5>Fast Delivery</h5>
                    <p>Delivered within 24 hours of harvest.</p>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="why-card">
                    <div class="icon-wrap" aria-hidden="true"><i class="fas fa-leaf"></i></div>
                    <h5>Eco Friendly</h5>
                    <p>Sustainable packaging and farming practices.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ===================== PRODUCTS SECTION ===================== -->
<section class="products-section" aria-labelledby="featured-heading">
    <div class="container">

        <?php if ($contentManager->get('welcome_message')): ?>
        <div class="welcome-alert mb-4" role="region" aria-label="Welcome message">
            <i class="fas fa-info-circle" aria-hidden="true"></i>
            <?php echo $contentManager->get('welcome_message', 'Welcome to Greenfield Local Hub!'); ?>
        </div>
        <?php endif; ?>

        <div class="section-header">
            <p class="eyebrow"><i class="fas fa-star" aria-hidden="true"></i> Handpicked for you</p>
            <h2 id="featured-heading">Featured Products</h2>
            <p>The freshest picks from our farmers this week</p>
            <div class="section-divider" aria-hidden="true"></div>
        </div>

        <div class="row g-4" id="productsContainer" aria-live="polite">
            <?php if (empty($products)): ?>
                <div class="col-12">
                    <div class="no-products-msg" role="status">
                        <i class="fas fa-seedling fa-2x mb-3 d-block" style="color:var(--accent-muted)" aria-hidden="true"></i>
                        No products available at the moment. Check back soon!
                    </div>
                </div>
            <?php else: ?>
                <?php
                $displayProducts = array_slice($products, 0, 6);
                foreach ($displayProducts as $product):
                    $price = isset($product['price']) ? $product['price'] : (isset($product['base_price']) ? $product['base_price'] : 0);
                    $formattedPrice = $currentCurrency['currency_symbol'] . number_format($price, 2);

                    // ── FIX: index.php lives in /public/ and uploads are in
                    //         /public/assets/uploads/ so image_url needs no prefix ──
                    if (!empty($product['image_url'])) {
                        $imagePath = $product['image_url'];          // e.g. assets/uploads/filename.jpg
                    } else {
                        $imagePath = 'assets/images/default-product.jpg';
                    }
                ?>
                <div class="col-sm-6 col-lg-4">
                    <article class="product-card" aria-label="<?php echo htmlspecialchars($product['name']); ?>">
                        <div class="img-wrapper">
                            <img src="<?php echo htmlspecialchars($imagePath); ?>"
                                 alt="<?php echo htmlspecialchars($product['name']); ?>"
                                 loading="lazy"
                                 onerror="this.onerror=null; this.src='assets/images/default-product.jpg';">
                            <span class="badge-fresh" aria-label="Fresh product">Fresh</span>
                        </div>
                        <div class="card-body">
                            <h3 class="card-title"><?php echo htmlspecialchars($product['name']); ?></h3>
                            <p class="card-text"><?php echo htmlspecialchars(substr($product['description'] ?? '', 0, 90)); ?><?php echo (strlen($product['description'] ?? '') > 90) ? '…' : ''; ?></p>
                            <div class="price-row">
                                <span class="price"><?php echo $formattedPrice; ?></span>
                                <span class="unit">/ <?php echo htmlspecialchars($product['unit'] ?? 'item'); ?></span>
                            </div>
                            <p class="producer">
                                <i class="fas fa-user-tie" aria-hidden="true"></i>
                                <?php echo htmlspecialchars($product['producer_name']); ?>
                            </p>
                            <div class="card-actions">
                                <?php if ($userObj->isLoggedIn() && $_SESSION['role'] == 'customer'): ?>
                                <button class="btn-add-cart add-to-cart"
                                        data-product-id="<?php echo (int)$product['id']; ?>"
                                        aria-label="Add <?php echo htmlspecialchars($product['name']); ?> to cart">
                                    <i class="fas fa-cart-plus" aria-hidden="true"></i> Add to Cart
                                </button>
                                <?php endif; ?>
                                <a href="product-details.php?id=<?php echo (int)$product['id']; ?>"
                                   class="btn-details"
                                   aria-label="View details for <?php echo htmlspecialchars($product['name']); ?>">
                                    <i class="fas fa-eye" aria-hidden="true"></i> Details
                                </a>
                            </div>
                        </div>
                    </article>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <?php if (!empty($products) && count($products) > 6): ?>
        <div class="text-center mt-5">
            <a href="products.php" class="btn-hero-primary" style="display:inline-flex">
                <i class="fas fa-store" aria-hidden="true"></i> View All Products
            </a>
        </div>
        <?php endif; ?>

    </div>
</section>
</main>

<!-- ===================== FOOTER ===================== -->
<footer role="contentinfo">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-4 col-md-6">
                <div class="footer-brand">
                    <i class="fas fa-seedling" aria-hidden="true"></i>
                    <?php echo htmlspecialchars($contentManager->get('site_title', 'Greenfield Local Hub')); ?>
                </div>
                <p class="footer-desc"><?php echo htmlspecialchars($contentManager->get('footer_text', 'Connecting local farmers with communities for fresher, fairer food.')); ?></p>
            </div>
            <div class="col-lg-2 col-md-6 col-6">
                <p class="footer-heading">Navigate</p>
                <a href="index.php" class="footer-link">Home</a>
                <a href="products.php" class="footer-link">Products</a>
                <a href="login.php" class="footer-link">Login</a>
                <a href="register.php" class="footer-link">Register</a>
            </div>
            <div class="col-lg-2 col-md-6 col-6">
                <p class="footer-heading">Account</p>
                <a href="order-history.php" class="footer-link">My Orders</a>
                <a href="cart.php" class="footer-link">Cart</a>
                <a href="logout.php" class="footer-link">Logout</a>
            </div>
            <div class="col-lg-4 col-md-6">
                <p class="footer-heading">Contact Us</p>
                <p class="footer-desc">
                    <i class="fas fa-envelope" aria-hidden="true"></i>
                    <a href="mailto:<?php echo htmlspecialchars($contentManager->get('contact_email','support@greenfieldhub.com')); ?>" class="footer-link d-inline">
                        <?php echo htmlspecialchars($contentManager->get('contact_email','support@greenfieldhub.com')); ?>
                    </a>
                </p>
                <p class="footer-desc mt-1">
                    <i class="fas fa-phone" aria-hidden="true"></i>
                    <?php echo htmlspecialchars($contentManager->get('contact_phone', '+1 (555) 123-4567')); ?>
                </p>
            </div>
        </div>
        <hr class="footer-divider" aria-hidden="true">
        <p class="footer-copy text-center">
            &copy; 2024 <?php echo htmlspecialchars($contentManager->get('site_title', 'Greenfield Local Hub')); ?>.
            All rights reserved.
        </p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function () {
    'use strict';

    /* ---- Accessibility Preferences ---- */
    const html       = document.documentElement;
    const THEME_KEY  = 'glh_theme';
    const FONT_KEY   = 'glh_font';

    function applyTheme(theme) {
        html.setAttribute('data-theme', theme || 'default');
        document.querySelectorAll('[id^="btn-theme-"]').forEach(btn => {
            btn.classList.remove('active');
            btn.setAttribute('aria-pressed', 'false');
        });
        if (theme === 'dark') {
            document.getElementById('btn-theme-dark').classList.add('active');
            document.getElementById('btn-theme-dark').setAttribute('aria-pressed', 'true');
        } else if (theme === 'high-contrast') {
            document.getElementById('btn-theme-high').classList.add('active');
            document.getElementById('btn-theme-high').setAttribute('aria-pressed', 'true');
        } else if (theme === 'low-contrast') {
            document.getElementById('btn-theme-low').classList.add('active');
            document.getElementById('btn-theme-low').setAttribute('aria-pressed', 'true');
        }
        localStorage.setItem(THEME_KEY, theme || 'default');
    }

    function toggleTheme(theme) {
        const current = html.getAttribute('data-theme');
        applyTheme(current === theme ? 'default' : theme);
    }

    function applyFontSize(size) {
        html.setAttribute('data-font-size', size || 'normal');
        const btn = document.getElementById('btn-font-large');
        const isLarge = size === 'large';
        btn.classList.toggle('active', isLarge);
        btn.setAttribute('aria-pressed', isLarge ? 'true' : 'false');
        localStorage.setItem(FONT_KEY, size || 'normal');
    }

    function toggleFontSize() {
        const current = html.getAttribute('data-font-size');
        applyFontSize(current === 'large' ? 'normal' : 'large');
    }

    /* Restore saved preferences */
    const savedTheme = localStorage.getItem(THEME_KEY);
    const savedFont  = localStorage.getItem(FONT_KEY);
    if (savedTheme) applyTheme(savedTheme);
    if (savedFont)  applyFontSize(savedFont);

    /* Button bindings */
    document.getElementById('btn-theme-dark').addEventListener('click', () => toggleTheme('dark'));
    document.getElementById('btn-theme-high').addEventListener('click', () => toggleTheme('high-contrast'));
    document.getElementById('btn-theme-low').addEventListener('click',  () => toggleTheme('low-contrast'));
    document.getElementById('btn-font-large').addEventListener('click', toggleFontSize);
    document.getElementById('btn-reset').addEventListener('click', () => {
        applyTheme('default');
        applyFontSize('normal');
    });

    /* ---- Cart count ---- */
    function loadCartCount() {
        $.ajax({
            url: '../ajax/load-cart-count.php',
            method: 'GET',
            success: function(response) {
                const count = parseInt(response) || 0;
                const badge = document.getElementById('cartCount');
                if (badge) {
                    badge.textContent = count;
                    badge.setAttribute('aria-label', count + ' item' + (count !== 1 ? 's' : '') + ' in cart');
                }
            }
        });
    }

    <?php if ($userObj->isLoggedIn() && $_SESSION['role'] == 'customer'): ?>
    loadCartCount();
    <?php endif; ?>

    /* ---- Currency Switcher ---- */
    document.querySelectorAll('.currency-option').forEach(function(el) {
        el.addEventListener('click', function() {
            const currencyCode = this.dataset.currency;
            $.ajax({
                url: 'set-currency.php',
                method: 'POST',
                data: { currency: currencyCode },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        Swal.fire({ title: 'Error', text: 'Failed to change currency', icon: 'error',
                            background: '#172d1a', color: '#e8f5e9',
                            confirmButtonColor: '#4caf50' });
                    }
                },
                error: function() {
                    Swal.fire({ title: 'Error', text: 'Failed to change currency', icon: 'error',
                        background: '#172d1a', color: '#e8f5e9',
                        confirmButtonColor: '#4caf50' });
                }
            });
        });
    });

    /* ---- Add to Cart ---- */
    document.querySelectorAll('.add-to-cart').forEach(function(btn) {
        btn.addEventListener('click', function() {
            const productId = this.dataset.productId;
            const originalHTML = this.innerHTML;
            this.disabled = true;
            this.innerHTML = '<i class="fas fa-spinner fa-spin" aria-hidden="true"></i> Adding…';

            $.ajax({
                url: '../ajax/add-to-cart.php',
                method: 'POST',
                data: { product_id: productId, quantity: 1 },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        Swal.fire({ title: 'Added!', text: 'Product added to cart!', icon: 'success',
                            timer: 1800, showConfirmButton: false,
                            background: '#172d1a', color: '#e8f5e9',
                            iconColor: '#4caf50' });
                        loadCartCount();
                    } else {
                        Swal.fire({ title: 'Error', text: response.message || 'Failed to add to cart', icon: 'error',
                            background: '#172d1a', color: '#e8f5e9',
                            confirmButtonColor: '#4caf50' });
                    }
                },
                error: function() {
                    Swal.fire({ title: 'Error', text: 'Failed to add to cart', icon: 'error',
                        background: '#172d1a', color: '#e8f5e9',
                        confirmButtonColor: '#4caf50' });
                },
                complete: function() {
                    btn.disabled = false;
                    btn.innerHTML = originalHTML;
                }
            });
        });
    });
})();
</script>
</body>
</html>