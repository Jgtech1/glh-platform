<?php
require_once '../classes/User.php';
$userObj = new User();

if ($userObj->isLoggedIn()) {
    header('Location: index.php');
    exit();
}

$error   = '';
$success = '';
$post    = $_POST; // preserve form values on error

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $result = $userObj->register($post);

    if ($result['success']) {
        $success = $result['message'];
    } else {
        $error = implode('<br>', $result['errors']);
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="default">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account — Greenfield Local Hub</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

        <link href="assets/css/style.css" rel="stylesheet">

</head>
<body>

<a class="skip-link" href="#main-content">Skip to main content</a>

<!-- Accessibility toolbar -->
<div class="a11y-toolbar" role="toolbar" aria-label="Accessibility options">
    <div class="inner">
        <span class="a11y-label" aria-hidden="true"><i class="fas fa-universal-access"></i> Accessibility:</span>
        <button class="a11y-btn" id="btn-theme-dark"  aria-pressed="false" title="Toggle dark mode"><i class="fas fa-moon" aria-hidden="true"></i> Dark</button>
        <div class="a11y-divider" role="separator" aria-hidden="true"></div>
        <button class="a11y-btn" id="btn-theme-high"  aria-pressed="false" title="High contrast"><i class="fas fa-adjust" aria-hidden="true"></i> High Contrast</button>
        <button class="a11y-btn" id="btn-theme-low"   aria-pressed="false" title="Low contrast"><i class="fas fa-circle-half-stroke" aria-hidden="true"></i> Low Contrast</button>
        <div class="a11y-divider" role="separator" aria-hidden="true"></div>
        <button class="a11y-btn" id="btn-font-large"  aria-pressed="false" title="Large text"><i class="fas fa-text-height" aria-hidden="true"></i> Large Text</button>
        <button class="a11y-btn" id="btn-reset"        title="Reset appearance"><i class="fas fa-rotate-left" aria-hidden="true"></i> Reset</button>
    </div>
</div>

<!-- Top nav -->
<nav class="top-nav" aria-label="Site navigation">
    <a class="brand-link" href="index.php" aria-label="Greenfield Local Hub home">
        <div class="brand-leaf" aria-hidden="true"><i class="fas fa-seedling"></i></div>
        Greenfield Local Hub
    </a>
    <a class="back-link" href="login.php">
        <i class="fas fa-arrow-left" aria-hidden="true"></i> Back to Login
    </a>
</nav>

<!-- Main -->
<main id="main-content" class="page-body">
    <div class="register-card" role="region" aria-label="Registration form">

        <p class="card-eyebrow"><i class="fas fa-leaf" aria-hidden="true"></i> Join the community</p>
        <h1 class="card-title">Create your account</h1>
        <p class="card-subtitle">Fresh produce, local farmers, delivered to your door.</p>

        <?php if ($error): ?>
        <div class="error-box" role="alert" aria-live="assertive">
            <i class="fas fa-circle-exclamation" style="flex-shrink:0;margin-top:2px" aria-hidden="true"></i>
            <span><?php echo $error; ?></span>
        </div>
        <?php endif; ?>

        <?php if ($success): ?>
        <div class="success-box" role="status" aria-live="polite">
            <i class="fas fa-circle-check" style="flex-shrink:0;margin-top:2px" aria-hidden="true"></i>
            <span><?php echo htmlspecialchars($success); ?></span>
        </div>
        <?php endif; ?>

        <form method="POST" id="registerForm" novalidate>

            <!-- Account info -->
            <div class="form-section">
                <p class="form-section-label"><i class="fas fa-user-circle" aria-hidden="true"></i> Account Info</p>
                <div class="field-row">
                    <div class="field-group">
                        <label class="field-label" for="username">Username <span class="req" aria-hidden="true">*</span></label>
                        <div class="field-wrap">
                            <input class="field-input" type="text" id="username" name="username"
                                   autocomplete="username" placeholder="e.g. john_doe"
                                   required aria-required="true"
                                   value="<?php echo htmlspecialchars($post['username'] ?? ''); ?>">
                            <i class="fas fa-at field-icon" aria-hidden="true"></i>
                        </div>
                    </div>
                    <div class="field-group">
                        <label class="field-label" for="full_name">Full Name <span class="req" aria-hidden="true">*</span></label>
                        <div class="field-wrap">
                            <input class="field-input" type="text" id="full_name" name="full_name"
                                   autocomplete="name" placeholder="Your full name"
                                   required aria-required="true"
                                   value="<?php echo htmlspecialchars($post['full_name'] ?? ''); ?>">
                            <i class="fas fa-id-card field-icon" aria-hidden="true"></i>
                        </div>
                    </div>
                </div>
                <div class="field-group">
                    <label class="field-label" for="email">Email Address <span class="req" aria-hidden="true">*</span></label>
                    <div class="field-wrap">
                        <input class="field-input" type="email" id="email" name="email"
                               autocomplete="email" placeholder="you@example.com"
                               required aria-required="true"
                               value="<?php echo htmlspecialchars($post['email'] ?? ''); ?>">
                        <i class="fas fa-envelope field-icon" aria-hidden="true"></i>
                    </div>
                </div>
                <div class="field-group">
                    <label class="field-label" for="password">Password <span class="req" aria-hidden="true">*</span></label>
                    <div class="field-wrap">
                        <input class="field-input has-toggle" type="password" id="password" name="password"
                               autocomplete="new-password" placeholder="Minimum 6 characters"
                               required aria-required="true" aria-describedby="pw-strength-text">
                        <i class="fas fa-lock field-icon" aria-hidden="true"></i>
                        <button type="button" class="pw-toggle" id="pwToggle"
                                aria-label="Show password" aria-pressed="false">
                            <i class="fas fa-eye" aria-hidden="true"></i>
                        </button>
                    </div>
                    <div class="strength-bar" aria-hidden="true">
                        <div class="strength-fill" id="strengthFill"></div>
                    </div>
                    <span class="strength-text" id="pw-strength-text" aria-live="polite"></span>
                </div>
            </div>

            <!-- Contact info -->
            <div class="form-section">
                <p class="form-section-label"><i class="fas fa-address-book" aria-hidden="true"></i> Contact Details</p>
                <div class="field-group">
                    <label class="field-label" for="phone">Phone Number</label>
                    <div class="field-wrap">
                        <input class="field-input" type="tel" id="phone" name="phone"
                               autocomplete="tel" placeholder="+1 (555) 000-0000"
                               value="<?php echo htmlspecialchars($post['phone'] ?? ''); ?>">
                        <i class="fas fa-phone field-icon" aria-hidden="true"></i>
                    </div>
                </div>
                <div class="field-group">
                    <label class="field-label" for="address">Delivery Address</label>
                    <div class="field-wrap">
                        <textarea class="field-input" id="address" name="address"
                                  rows="2" placeholder="Street, City, Postcode"
                                  style="padding-top:0.65rem"
                                  autocomplete="street-address"><?php echo htmlspecialchars($post['address'] ?? ''); ?></textarea>
                        <i class="fas fa-map-marker-alt field-icon" aria-hidden="true"></i>
                    </div>
                </div>
            </div>

            <!-- Role -->
            <div class="form-section">
                <p class="form-section-label"><i class="fas fa-user-tag" aria-hidden="true"></i> I want to join as</p>
                <div class="role-cards" role="radiogroup" aria-label="Account type">
                    <div class="role-card">
                        <input type="radio" id="role-customer" name="role" value="customer"
                               <?php echo (!isset($post['role']) || $post['role'] === 'customer') ? 'checked' : ''; ?>>
                        <label for="role-customer">
                            <i class="fas fa-shopping-basket" aria-hidden="true"></i>
                            Customer
                            <span class="role-desc">Browse & buy fresh produce</span>
                        </label>
                    </div>
                    <div class="role-card">
                        <input type="radio" id="role-producer" name="role" value="producer"
                               <?php echo (isset($post['role']) && $post['role'] === 'producer') ? 'checked' : ''; ?>>
                        <label for="role-producer">
                            <i class="fas fa-tractor" aria-hidden="true"></i>
                            Producer
                            <span class="role-desc">Sell your farm products</span>
                        </label>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn-submit" id="submitBtn">
                <i class="fas fa-seedling" aria-hidden="true"></i>
                <span id="submitLabel">Create Account</span>
            </button>
        </form>

        <div class="form-divider" aria-hidden="true">or</div>

        <div class="card-footer-links">
            <p>Already have an account? <a href="login.php">Sign in here</a></p>
        </div>
    </div>
</main>

<footer class="page-footer" role="contentinfo">
    <p>&copy; 2024 <a href="index.php">Greenfield Local Hub</a>. All rights reserved.</p>
</footer>

<?php if ($success): ?>
<script>
    // Redirect after successful registration
    Swal.fire({
        title: 'Account Created!',
        text: 'Welcome to Greenfield! Please sign in.',
        icon: 'success',
        confirmButtonText: 'Go to Login',
        background: '#172d1a',
        color: '#e8f5e9',
        iconColor: '#4caf50',
        confirmButtonColor: '#2e7d32'
    }).then(function() {
        window.location.href = 'login.php';
    });
</script>
<?php endif; ?>

<script>
(function () {
    'use strict';

    /* ---- Accessibility (shared theme engine) ---- */
    var html      = document.documentElement;
    var THEME_KEY = 'glh_theme';
    var FONT_KEY  = 'glh_font';

    function applyTheme(theme) {
        html.setAttribute('data-theme', theme || 'default');
        ['dark','high','low'].forEach(function(t) {
            var btn = document.getElementById('btn-theme-' + t);
            if (btn) { btn.classList.remove('active'); btn.setAttribute('aria-pressed','false'); }
        });
        var map = { dark: 'btn-theme-dark', 'high-contrast': 'btn-theme-high', 'low-contrast': 'btn-theme-low' };
        if (map[theme]) {
            var el = document.getElementById(map[theme]);
            if (el) { el.classList.add('active'); el.setAttribute('aria-pressed','true'); }
        }
        localStorage.setItem(THEME_KEY, theme || 'default');
    }
    function toggleTheme(theme) { applyTheme(html.getAttribute('data-theme') === theme ? 'default' : theme); }

    function applyFontSize(size) {
        html.setAttribute('data-font-size', size || 'normal');
        var btn = document.getElementById('btn-font-large');
        var large = size === 'large';
        btn.classList.toggle('active', large);
        btn.setAttribute('aria-pressed', large ? 'true' : 'false');
        localStorage.setItem(FONT_KEY, size || 'normal');
    }
    function toggleFont() { applyFontSize(html.getAttribute('data-font-size') === 'large' ? 'normal' : 'large'); }

    var savedTheme = localStorage.getItem(THEME_KEY);
    var savedFont  = localStorage.getItem(FONT_KEY);
    if (savedTheme) applyTheme(savedTheme);
    if (savedFont)  applyFontSize(savedFont);

    document.getElementById('btn-theme-dark').addEventListener('click', function(){ toggleTheme('dark'); });
    document.getElementById('btn-theme-high').addEventListener('click', function(){ toggleTheme('high-contrast'); });
    document.getElementById('btn-theme-low').addEventListener('click',  function(){ toggleTheme('low-contrast'); });
    document.getElementById('btn-font-large').addEventListener('click', toggleFont);
    document.getElementById('btn-reset').addEventListener('click', function(){ applyTheme('default'); applyFontSize('normal'); });

    /* ---- Password visibility toggle ---- */
    var pwInput  = document.getElementById('password');
    var pwToggle = document.getElementById('pwToggle');
    var pwIcon   = pwToggle.querySelector('i');
    pwToggle.addEventListener('click', function() {
        var hidden = pwInput.type === 'password';
        pwInput.type = hidden ? 'text' : 'password';
        pwIcon.className = hidden ? 'fas fa-eye-slash' : 'fas fa-eye';
        pwToggle.setAttribute('aria-label',   hidden ? 'Hide password' : 'Show password');
        pwToggle.setAttribute('aria-pressed',  hidden ? 'true' : 'false');
        pwInput.focus();
    });

    /* ---- Password strength meter ---- */
    var fill  = document.getElementById('strengthFill');
    var label = document.getElementById('pw-strength-text');
    var levels = [
        { max: 0,  pct: 0,   color: 'transparent',  text: '' },
        { max: 2,  pct: 25,  color: '#e53935',       text: 'Weak' },
        { max: 3,  pct: 50,  color: '#fb8c00',       text: 'Fair' },
        { max: 4,  pct: 75,  color: '#fdd835',       text: 'Good' },
        { max: 99, pct: 100, color: '#43a047',       text: 'Strong ✓' }
    ];
    pwInput.addEventListener('input', function() {
        var v = pwInput.value;
        var score = 0;
        if (v.length >= 6)               score++;
        if (v.length >= 10)              score++;
        if (/[A-Z]/.test(v))             score++;
        if (/[0-9]/.test(v))             score++;
        if (/[^A-Za-z0-9]/.test(v))      score++;
        var lvl = levels[Math.min(score, levels.length - 1)];
        fill.style.width      = lvl.pct + '%';
        fill.style.background = lvl.color;
        label.textContent     = v.length ? lvl.text : '';
    });

    /* ---- Submit loading state ---- */
    document.getElementById('registerForm').addEventListener('submit', function() {
        var btn   = document.getElementById('submitBtn');
        var lbl   = document.getElementById('submitLabel');
        btn.disabled = true;
        lbl.textContent = 'Creating account…';
        btn.querySelector('i').className = 'fas fa-spinner fa-spin';
    });
})();
</script>
</body>
</html>