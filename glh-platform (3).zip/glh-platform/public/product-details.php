<?php
require_once '../classes/Product.php';
require_once '../classes/User.php';
require_once '../classes/ContentManager.php';
require_once '../classes/CurrencyManager.php';
require_once '../classes/Cart.php';

$productObj = new Product();
$userObj = new User();
$contentManager = new ContentManager();
$currencyManager = new CurrencyManager();
$cartObj = new Cart();

// Get product ID from URL
$productId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$product = $productObj->getProductById($productId);

// If product not found, redirect to products page
if (!$product) {
    header('Location: products.php');
    exit;
}

$currentCurrency = $currencyManager->getCurrentCurrency();
$formattedPrice = $currentCurrency['currency_symbol'] . number_format($product['price'], 2);

// Get related products from same producer
$relatedProducts = $productObj->getProductsByProducer($product['producer_id'], 4, $productId);

// Get cart count for logged in users
$cartCount = 0;
if ($userObj->isLoggedIn() && $_SESSION['role'] == 'customer') {
    $cartCount = $cartObj->getCartCount();
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="default">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($product['name']); ?> | <?php echo $contentManager->get('site_title', 'Greenfield Local Hub'); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">

    <!-- Libs -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

        <link href="assets/css/style.css" rel="stylesheet">

</head>
<body>

<a class="skip-link" href="#main-content">Skip to main content</a>

<?php if ($contentManager->get('promo_banner')): ?>
<div class="promo-banner" role="banner" aria-label="Promotional announcement">
    <i class="fas fa-tag" aria-hidden="true"></i>
    <?php echo $contentManager->render('promo_banner'); ?>
</div>
<?php endif; ?>

<!-- Accessibility Toolbar -->
<div class="a11y-toolbar" role="toolbar" aria-label="Accessibility options">
    <div class="container">
        <span class="a11y-label" aria-hidden="true"><i class="fas fa-universal-access"></i> Accessibility:</span>
        <button class="a11y-btn" id="btn-theme-dark" aria-pressed="false" title="Toggle dark mode">
            <i class="fas fa-moon" aria-hidden="true"></i> Dark
        </button>
        <div class="a11y-divider" role="separator" aria-hidden="true"></div>
        <button class="a11y-btn" id="btn-theme-high" aria-pressed="false" title="High contrast mode">
            <i class="fas fa-adjust" aria-hidden="true"></i> High Contrast
        </button>
        <button class="a11y-btn" id="btn-theme-low" aria-pressed="false" title="Low contrast mode">
            <i class="fas fa-circle-half-stroke" aria-hidden="true"></i> Low Contrast
        </button>
        <div class="a11y-divider" role="separator" aria-hidden="true"></div>
        <button class="a11y-btn" id="btn-font-large" aria-pressed="false" title="Toggle large text">
            <i class="fas fa-text-height" aria-hidden="true"></i> Large Text
        </button>
        <button class="a11y-btn" id="btn-reset" title="Reset to default appearance">
            <i class="fas fa-rotate-left" aria-hidden="true"></i> Reset
        </button>
    </div>
</div>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg" aria-label="Main navigation">
    <div class="container">
        <a class="navbar-brand" href="index.php" aria-label="Greenfield Local Hub home">
            <div class="brand-leaf" aria-hidden="true"><i class="fas fa-seedling"></i></div>
            <?php echo htmlspecialchars($contentManager->get('site_title', 'Greenfield Local Hub')); ?>
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarNav" aria-controls="navbarNav"
                aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto align-items-center" role="list">
                <li class="nav-item" role="listitem">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item" role="listitem">
                    <a class="nav-link" href="products.php">Products</a>
                </li>

                <?php if ($userObj->isLoggedIn()): ?>
                    <?php if ($_SESSION['role'] == 'customer'): ?>
                        <li class="nav-item" role="listitem">
                            <a class="nav-link" href="order-history.php">My Orders</a>
                        </li>
                        <li class="nav-item" role="listitem">
                            <a class="nav-link cart-wrapper" href="cart.php" aria-label="Shopping cart">
                                <i class="fas fa-shopping-cart" aria-hidden="true"></i> Cart
                                <span id="cartCount" class="cart-badge" aria-live="polite" aria-label="<?php echo $cartCount; ?> items in cart"><?php echo $cartCount; ?></span>
                            </a>
                        </li>
                    <?php elseif ($_SESSION['role'] == 'producer'): ?>
                        <li class="nav-item" role="listitem">
                            <a class="nav-link" href="../producer/dashboard.php">Dashboard</a>
                        </li>
                    <?php elseif ($_SESSION['role'] == 'admin'): ?>
                        <li class="nav-item" role="listitem">
                            <a class="nav-link" href="../admin/dashboard.php">Admin Panel</a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item" role="listitem">
                        <a class="nav-link" href="logout.php">
                            <i class="fas fa-sign-out-alt" aria-hidden="true"></i>
                            Logout <span class="text-accent">(<?php echo htmlspecialchars($_SESSION['username']); ?>)</span>
                        </a>
                    </li>
                <?php else: ?>
                    <li class="nav-item" role="listitem">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>
                    <li class="nav-item" role="listitem">
                        <a class="nav-link" href="register.php">Register</a>
                    </li>
                <?php endif; ?>

                <li class="nav-item dropdown" role="listitem">
                    <button class="nav-link dropdown-toggle btn btn-link border-0"
                            id="currencyDropdown" aria-haspopup="true" aria-expanded="false"
                            data-bs-toggle="dropdown"
                            aria-label="Select currency: <?php echo htmlspecialchars($currentCurrency['currency_code']); ?>">
                        <?php echo htmlspecialchars($currentCurrency['currency_symbol']); ?>
                        <?php echo htmlspecialchars($currentCurrency['currency_code']); ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="currencyDropdown">
                        <?php foreach ($currencyManager->getAllCurrencies() as $currency): ?>
                            <li>
                                <button class="dropdown-item currency-option"
                                        data-currency="<?php echo htmlspecialchars($currency['currency_code']); ?>">
                                    <?php echo htmlspecialchars($currency['currency_symbol']); ?>
                                    <?php echo htmlspecialchars($currency['currency_code']); ?> –
                                    <?php echo htmlspecialchars($currency['currency_name']); ?>
                                </button>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Breadcrumb -->
<div class="breadcrumb-wrapper">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item"><a href="products.php">Products</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo htmlspecialchars($product['name']); ?></li>
            </ol>
        </nav>
    </div>
</div>

<main id="main-content">
<!-- Product Details Section -->
<section class="product-details-section">
    <div class="container">
        <div class="row g-5">
            <!-- Product Image Gallery -->
            <div class="col-lg-6">
                <div class="product-gallery">
                    <?php
                    $imagePath = !empty($product['image_url']) ? '../' . $product['image_url'] : 'assets/images/default-product.jpg';
                    ?>
                    <img src="<?php echo htmlspecialchars($imagePath); ?>"
                         alt="<?php echo htmlspecialchars($product['name']); ?>"
                         class="main-image"
                         onerror="this.src='assets/images/default-product.jpg'">
                    <span class="product-badge">Fresh</span>
                    <span class="stock-badge <?php
                        if ($product['stock_quantity'] <= 0) echo 'out-of-stock';
                        elseif ($product['stock_quantity'] < 10) echo 'low-stock';
                        else echo 'in-stock';
                    ?>">
                        <?php if ($product['stock_quantity'] <= 0): ?>
                            <i class="fas fa-times-circle" aria-hidden="true"></i> Out of Stock
                        <?php elseif ($product['stock_quantity'] < 10): ?>
                            <i class="fas fa-exclamation-triangle" aria-hidden="true"></i> Only <?php echo $product['stock_quantity']; ?> left
                        <?php else: ?>
                            <i class="fas fa-check-circle" aria-hidden="true"></i> In Stock
                        <?php endif; ?>
                    </span>
                </div>
            </div>

            <!-- Product Info -->
            <div class="col-lg-6">
                <div class="product-info">
                    <span class="product-category">
                        <i class="fas fa-tag" aria-hidden="true"></i>
                        <?php echo htmlspecialchars($product['category_name'] ?? 'Farm Fresh'); ?>
                    </span>
                    <h1 class="product-title"><?php echo htmlspecialchars($product['name']); ?></h1>

                    <div class="producer-info">
                        <div class="producer-avatar" aria-hidden="true">
                            <i class="fas fa-user-tie"></i>
                        </div>
                        <span class="producer-name">
                            By <a href="producer-products.php?id=<?php echo $product['producer_id']; ?>">
                                <?php echo htmlspecialchars($product['producer_name']); ?>
                            </a>
                        </span>
                    </div>

                    <div class="price-wrapper">
                        <div>
                            <span class="current-price"><?php echo $formattedPrice; ?></span>
                            <?php if (isset($product['original_price']) && $product['original_price'] > $product['price']): ?>
                                <span class="original-price">
                                    <?php echo $currentCurrency['currency_symbol'] . number_format($product['original_price'], 2); ?>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="unit-info">
                            <i class="fas fa-weight-hanging" aria-hidden="true"></i>
                            Price per <?php echo htmlspecialchars($product['unit'] ?? 'item'); ?>
                        </div>
                    </div>

                    <div class="product-description">
                        <p><?php echo nl2br(htmlspecialchars($product['description'] ?? 'No description available.')); ?></p>
                    </div>

                    <div class="product-meta">
                        <div class="meta-item">
                            <i class="fas fa-map-marker-alt" aria-hidden="true"></i>
                            <span><?php echo htmlspecialchars($product['farm_location'] ?? 'Local Farm'); ?></span>
                        </div>
                        <div class="meta-item">
                            <i class="fas fa-calendar-alt" aria-hidden="true"></i>
                            <span>Harvested: <?php echo date('M j, Y', strtotime($product['harvest_date'] ?? 'now')); ?></span>
                        </div>
                        <?php if (!empty($product['certification'])): ?>
                        <div class="meta-item">
                            <i class="fas fa-certificate" aria-hidden="true"></i>
                            <span><?php echo htmlspecialchars($product['certification']); ?></span>
                        </div>
                        <?php endif; ?>
                    </div>

                    <?php if ($userObj->isLoggedIn() && $_SESSION['role'] == 'customer' && $product['stock_quantity'] > 0): ?>
                    <!-- Quantity Selector -->
                    <div class="quantity-selector">
                        <span class="quantity-label">Quantity:</span>
                        <div class="quantity-control">
                            <button class="quantity-btn" id="qtyMinus" aria-label="Decrease quantity">−</button>
                            <input type="number" id="quantityInput" class="quantity-input" value="1" min="1" max="<?php echo $product['stock_quantity']; ?>" step="1">
                            <button class="quantity-btn" id="qtyPlus" aria-label="Increase quantity">+</button>
                        </div>
                        <span class="text-muted small">(Max <?php echo $product['stock_quantity']; ?> available)</span>
                    </div>

                    <!-- Action Buttons -->
                    <div class="action-buttons">
                        <button class="btn-add-cart-detail" id="addToCartBtn" data-product-id="<?php echo $product['id']; ?>">
                            <i class="fas fa-cart-plus" aria-hidden="true"></i> Add to Cart
                        </button>
                        <button class="btn-wishlist" id="wishlistBtn" data-product-id="<?php echo $product['id']; ?>">
                            <i class="far fa-heart" aria-hidden="true"></i> Wishlist
                        </button>
                    </div>
                    <?php elseif ($product['stock_quantity'] <= 0): ?>
                    <div class="alert alert-danger mt-3" style="background: rgba(229,57,53,0.15); border-color: #e53935; color: #ff8a80;">
                        <i class="fas fa-ban" aria-hidden="true"></i> This product is currently out of stock.
                    </div>
                    <?php elseif (!$userObj->isLoggedIn()): ?>
                    <div class="alert alert-info mt-3" style="background: rgba(76,175,80,0.15); border-color: var(--accent-muted);">
                        <i class="fas fa-info-circle" aria-hidden="true"></i>
                        <a href="login.php" class="text-accent">Login</a> to add this item to your cart.
                    </div>
                    <?php endif; ?>

                    <!-- Share Section -->
                    <div class="share-section">
                        <span class="share-label"><i class="fas fa-share-alt" aria-hidden="true"></i> Share:</span>
                        <a href="#" class="share-link" id="shareFacebook" aria-label="Share on Facebook">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="#" class="share-link" id="shareTwitter" aria-label="Share on Twitter">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a href="#" class="share-link" id="shareWhatsapp" aria-label="Share on WhatsApp">
                            <i class="fab fa-whatsapp"></i>
                        </a>
                        <button class="share-link btn btn-link p-0" id="copyLinkBtn" aria-label="Copy product link" style="background: none; border: none; display: inline; font-size: 1.1rem;">
                            <i class="fas fa-link"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Related Products Section -->
<?php if (!empty($relatedProducts)): ?>
<section class="related-section" aria-labelledby="related-heading">
    <div class="container">
        <div class="related-header">
            <p class="eyebrow"><i class="fas fa-seedling" aria-hidden="true"></i> You might also like</p>
            <h2 id="related-heading">More from <?php echo htmlspecialchars($product['producer_name']); ?></h2>
            <div class="section-divider" aria-hidden="true"></div>
        </div>

        <div class="row g-4" id="relatedProductsContainer">
            <?php foreach ($relatedProducts as $related):
                $relatedPrice = $currentCurrency['currency_symbol'] . number_format($related['price'], 2);
                $relatedImage = !empty($related['image_url']) ? '../' . $related['image_url'] : 'assets/images/default-product.jpg';
            ?>
            <div class="col-sm-6 col-lg-3">
                <article class="product-card" aria-label="<?php echo htmlspecialchars($related['name']); ?>">
                    <div class="img-wrapper">
                        <img src="<?php echo htmlspecialchars($relatedImage); ?>"
                             alt="<?php echo htmlspecialchars($related['name']); ?>"
                             loading="lazy"
                             onerror="this.src='assets/images/default-product.jpg'">
                        <span class="badge-fresh" aria-label="Fresh product">Fresh</span>
                    </div>
                    <div class="card-body">
                        <h3 class="card-title"><?php echo htmlspecialchars($related['name']); ?></h3>
                        <p class="card-text"><?php echo htmlspecialchars(substr($related['description'] ?? '', 0, 70)); ?><?php echo (strlen($related['description'] ?? '') > 70) ? '…' : ''; ?></p>
                        <div class="price-row">
                            <span class="price"><?php echo $relatedPrice; ?></span>
                            <span class="unit">/ <?php echo htmlspecialchars($related['unit'] ?? 'item'); ?></span>
                        </div>
                        <div class="card-actions">
                            <?php if ($userObj->isLoggedIn() && $_SESSION['role'] == 'customer' && $related['stock_quantity'] > 0): ?>
                            <button class="btn-add-cart-related add-to-cart-related"
                                    data-product-id="<?php echo (int)$related['id']; ?>"
                                    aria-label="Add <?php echo htmlspecialchars($related['name']); ?> to cart">
                                <i class="fas fa-cart-plus" aria-hidden="true"></i> Add
                            </button>
                            <?php endif; ?>
                            <a href="product-details.php?id=<?php echo (int)$related['id']; ?>"
                               class="btn-details-related"
                               aria-label="View details for <?php echo htmlspecialchars($related['name']); ?>">
                                <i class="fas fa-eye" aria-hidden="true"></i> View
                            </a>
                        </div>
                    </div>
                </article>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>
</main>

<!-- Footer -->
<footer role="contentinfo">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-4 col-md-6">
                <div class="footer-brand">
                    <i class="fas fa-seedling" aria-hidden="true"></i>
                    <?php echo htmlspecialchars($contentManager->get('site_title', 'Greenfield Local Hub')); ?>
                </div>
                <p class="footer-desc"><?php echo htmlspecialchars($contentManager->get('footer_text', 'Connecting local farmers with communities for fresher, fairer food.')); ?></p>
            </div>
            <div class="col-lg-2 col-md-6 col-6">
                <p class="footer-heading">Navigate</p>
                <a href="index.php" class="footer-link">Home</a>
                <a href="products.php" class="footer-link">Products</a>
                <a href="login.php" class="footer-link">Login</a>
                <a href="register.php" class="footer-link">Register</a>
            </div>
            <div class="col-lg-2 col-md-6 col-6">
                <p class="footer-heading">Account</p>
                <a href="order-history.php" class="footer-link">My Orders</a>
                <a href="cart.php" class="footer-link">Cart</a>
                <a href="logout.php" class="footer-link">Logout</a>
            </div>
            <div class="col-lg-4 col-md-6">
                <p class="footer-heading">Contact Us</p>
                <p class="footer-desc">
                    <i class="fas fa-envelope" aria-hidden="true"></i>
                    <a href="mailto:<?php echo htmlspecialchars($contentManager->get('contact_email','support@greenfieldhub.com')); ?>" class="footer-link d-inline">
                        <?php echo htmlspecialchars($contentManager->get('contact_email','support@greenfieldhub.com')); ?>
                    </a>
                </p>
                <p class="footer-desc mt-1">
                    <i class="fas fa-phone" aria-hidden="true"></i>
                    <?php echo htmlspecialchars($contentManager->get('contact_phone', '+1 (555) 123-4567')); ?>
                </p>
            </div>
        </div>
        <hr class="footer-divider" aria-hidden="true">
        <p class="footer-copy text-center">
            &copy; 2024 <?php echo htmlspecialchars($contentManager->get('site_title', 'Greenfield Local Hub')); ?>.
            All rights reserved.
        </p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function () {
    'use strict';

    // Accessibility Preferences
    const html = document.documentElement;
    const THEME_KEY = 'glh_theme';
    const FONT_KEY = 'glh_font';

    function applyTheme(theme) {
        html.setAttribute('data-theme', theme || 'default');
        document.querySelectorAll('[id^="btn-theme-"]').forEach(btn => {
            btn.classList.remove('active');
            btn.setAttribute('aria-pressed', 'false');
        });
        if (theme === 'dark') {
            document.getElementById('btn-theme-dark').classList.add('active');
            document.getElementById('btn-theme-dark').setAttribute('aria-pressed', 'true');
        } else if (theme === 'high-contrast') {
            document.getElementById('btn-theme-high').classList.add('active');
            document.getElementById('btn-theme-high').setAttribute('aria-pressed', 'true');
        } else if (theme === 'low-contrast') {
            document.getElementById('btn-theme-low').classList.add('active');
            document.getElementById('btn-theme-low').setAttribute('aria-pressed', 'true');
        }
        localStorage.setItem(THEME_KEY, theme || 'default');
    }

    function toggleTheme(theme) {
        const current = html.getAttribute('data-theme');
        applyTheme(current === theme ? 'default' : theme);
    }

    function applyFontSize(size) {
        html.setAttribute('data-font-size', size || 'normal');
        const btn = document.getElementById('btn-font-large');
        const isLarge = size === 'large';
        btn.classList.toggle('active', isLarge);
        btn.setAttribute('aria-pressed', isLarge ? 'true' : 'false');
        localStorage.setItem(FONT_KEY, size || 'normal');
    }

    function toggleFontSize() {
        const current = html.getAttribute('data-font-size');
        applyFontSize(current === 'large' ? 'normal' : 'large');
    }

    const savedTheme = localStorage.getItem(THEME_KEY);
    const savedFont = localStorage.getItem(FONT_KEY);
    if (savedTheme) applyTheme(savedTheme);
    if (savedFont) applyFontSize(savedFont);

    document.getElementById('btn-theme-dark')?.addEventListener('click', () => toggleTheme('dark'));
    document.getElementById('btn-theme-high')?.addEventListener('click', () => toggleTheme('high-contrast'));
    document.getElementById('btn-theme-low')?.addEventListener('click', () => toggleTheme('low-contrast'));
    document.getElementById('btn-font-large')?.addEventListener('click', toggleFontSize);
    document.getElementById('btn-reset')?.addEventListener('click', () => {
        applyTheme('default');
        applyFontSize('normal');
    });

    // Cart count update function
    function loadCartCount() {
        $.ajax({
            url: '../ajax/load-cart-count.php',
            method: 'GET',
            success: function(response) {
                const count = parseInt(response) || 0;
                const badge = document.getElementById('cartCount');
                if (badge) {
                    badge.textContent = count;
                    badge.setAttribute('aria-label', count + ' item' + (count !== 1 ? 's' : '') + ' in cart');
                }
            }
        });
    }

    <?php if ($userObj->isLoggedIn() && $_SESSION['role'] == 'customer'): ?>
    loadCartCount();
    <?php endif; ?>

    // Currency Switcher
    document.querySelectorAll('.currency-option').forEach(function(el) {
        el.addEventListener('click', function() {
            const currencyCode = this.dataset.currency;
            $.ajax({
                url: 'set-currency.php',
                method: 'POST',
                data: { currency: currencyCode },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        Swal.fire({ title: 'Error', text: 'Failed to change currency', icon: 'error',
                            background: '#172d1a', color: '#e8f5e9',
                            confirmButtonColor: '#4caf50' });
                    }
                },
                error: function() {
                    Swal.fire({ title: 'Error', text: 'Failed to change currency', icon: 'error',
                        background: '#172d1a', color: '#e8f5e9',
                        confirmButtonColor: '#4caf50' });
                }
            });
        });
    });

    // Quantity selector
    const qtyInput = document.getElementById('quantityInput');
    const qtyMinus = document.getElementById('qtyMinus');
    const qtyPlus = document.getElementById('qtyPlus');
    const maxStock = <?php echo $product['stock_quantity']; ?>;

    if (qtyInput) {
        function updateQuantityButtons() {
            const val = parseInt(qtyInput.value) || 1;
            qtyMinus.disabled = val <= 1;
            qtyPlus.disabled = val >= maxStock;
        }

        qtyMinus?.addEventListener('click', () => {
            let val = parseInt(qtyInput.value) || 1;
            if (val > 1) {
                qtyInput.value = val - 1;
                updateQuantityButtons();
            }
        });

        qtyPlus?.addEventListener('click', () => {
            let val = parseInt(qtyInput.value) || 1;
            if (val < maxStock) {
                qtyInput.value = val + 1;
                updateQuantityButtons();
            }
        });

        qtyInput.addEventListener('change', () => {
            let val = parseInt(qtyInput.value) || 1;
            val = Math.min(maxStock, Math.max(1, val));
            qtyInput.value = val;
            updateQuantityButtons();
        });

        updateQuantityButtons();
    }

    // Add to Cart (Main)
    const addToCartBtn = document.getElementById('addToCartBtn');
    if (addToCartBtn) {
        addToCartBtn.addEventListener('click', function() {
            const productId = this.dataset.productId;
            const quantity = parseInt(document.getElementById('quantityInput')?.value) || 1;
            const originalHTML = this.innerHTML;

            this.disabled = true;
            this.innerHTML = '<i class="fas fa-spinner fa-spin" aria-hidden="true"></i> Adding…';

            $.ajax({
                url: '../ajax/add-to-cart.php',
                method: 'POST',
                data: { product_id: productId, quantity: quantity },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        Swal.fire({
                            title: 'Added to Cart!',
                            text: 'Product has been added to your cart.',
                            icon: 'success',
                            timer: 2000,
                            showConfirmButton: false,
                            background: '#172d1a',
                            color: '#e8f5e9',
                            iconColor: '#4caf50'
                        });
                        loadCartCount();
                    } else {
                        Swal.fire({
                            title: 'Error',
                            text: response.message || 'Failed to add to cart',
                            icon: 'error',
                            background: '#172d1a',
                            color: '#e8f5e9',
                            confirmButtonColor: '#4caf50'
                        });
                    }
                },
                error: function() {
                    Swal.fire({
                        title: 'Error',
                        text: 'Failed to add to cart',
                        icon: 'error',
                        background: '#172d1a',
                        color: '#e8f5e9',
                        confirmButtonColor: '#4caf50'
                    });
                },
                complete: function() {
                    addToCartBtn.disabled = false;
                    addToCartBtn.innerHTML = originalHTML;
                }
            });
        });
    }

    // Add to Cart for Related Products
    document.querySelectorAll('.add-to-cart-related').forEach(function(btn) {
        btn.addEventListener('click', function() {
            const productId = this.dataset.productId;
            const originalHTML = this.innerHTML;
            this.disabled = true;
            this.innerHTML = '<i class="fas fa-spinner fa-spin" aria-hidden="true"></i>';

            $.ajax({
                url: '../ajax/add-to-cart.php',
                method: 'POST',
                data: { product_id: productId, quantity: 1 },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        Swal.fire({
                            title: 'Added!',
                            text: 'Product added to cart!',
                            icon: 'success',
                            timer: 1500,
                            showConfirmButton: false,
                            background: '#172d1a',
                            color: '#e8f5e9',
                            iconColor: '#4caf50'
                        });
                        loadCartCount();
                    } else {
                        Swal.fire({
                            title: 'Error',
                            text: response.message || 'Failed to add to cart',
                            icon: 'error',
                            background: '#172d1a',
                            color: '#e8f5e9',
                            confirmButtonColor: '#4caf50'
                        });
                    }
                },
                error: function() {
                    Swal.fire({
                        title: 'Error',
                        text: 'Failed to add to cart',
                        icon: 'error',
                        background: '#172d1a',
                        color: '#e8f5e9',
                        confirmButtonColor: '#4caf50'
                    });
                },
                complete: function() {
                    btn.disabled = false;
                    btn.innerHTML = originalHTML;
                }
            });
        });
    });

    // Wishlist functionality
    const wishlistBtn = document.getElementById('wishlistBtn');
    if (wishlistBtn) {
        wishlistBtn.addEventListener('click', function() {
            const productId = this.dataset.productId;
            const originalHTML = this.innerHTML;

            this.disabled = true;
            this.innerHTML = '<i class="fas fa-spinner fa-spin" aria-hidden="true"></i>';

            $.ajax({
                url: '../ajax/add-to-wishlist.php',
                method: 'POST',
                data: { product_id: productId },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        Swal.fire({
                            title: 'Added to Wishlist!',
                            text: 'Product saved to your wishlist.',
                            icon: 'success',
                            timer: 2000,
                            showConfirmButton: false,
                            background: '#172d1a',
                            color: '#e8f5e9',
                            iconColor: '#4caf50'
                        });
                        wishlistBtn.innerHTML = '<i class="fas fa-heart" aria-hidden="true"></i> Wishlisted';
                    } else if (response.already_exists) {
                        Swal.fire({
                            title: 'Already in Wishlist',
                            text: 'This product is already in your wishlist.',
                            icon: 'info',
                            timer: 2000,
                            showConfirmButton: false,
                            background: '#172d1a',
                            color: '#e8f5e9'
                        });
                        wishlistBtn.innerHTML = originalHTML;
                    } else {
                        Swal.fire({
                            title: 'Error',
                            text: response.message || 'Failed to add to wishlist',
                            icon: 'error',
                            background: '#172d1a',
                            color: '#e8f5e9',
                            confirmButtonColor: '#4caf50'
                        });
                        wishlistBtn.innerHTML = originalHTML;
                    }
                },
                error: function() {
                    Swal.fire({
                        title: 'Error',
                        text: 'Failed to add to wishlist',
                        icon: 'error',
                        background: '#172d1a',
                        color: '#e8f5e9',
                        confirmButtonColor: '#4caf50'
                    });
                    wishlistBtn.innerHTML = originalHTML;
                },
                complete: function() {
                    wishlistBtn.disabled = false;
                }
            });
        });
    }

    // Share functionality
    const currentUrl = encodeURIComponent(window.location.href);
    const productTitle = encodeURIComponent("<?php echo htmlspecialchars($product['name']); ?>");

    document.getElementById('shareFacebook')?.addEventListener('click', (e) => {
        e.preventDefault();
        window.open(`https://www.facebook.com/sharer/sharer.php?u=${currentUrl}`, '_blank', 'width=600,height=400');
    });

    document.getElementById('shareTwitter')?.addEventListener('click', (e) => {
        e.preventDefault();
        window.open(`https://twitter.com/intent/tweet?text=Check out ${productTitle}&url=${currentUrl}`, '_blank', 'width=600,height=400');
    });

    document.getElementById('shareWhatsapp')?.addEventListener('click', (e) => {
        e.preventDefault();
        window.open(`https://wa.me/?text=${productTitle}%20${currentUrl}`, '_blank');
    });

    document.getElementById('copyLinkBtn')?.addEventListener('click', () => {
        navigator.clipboard.writeText(window.location.href).then(() => {
            Swal.fire({
                title: 'Link Copied!',
                text: 'Product link copied to clipboard',
                icon: 'success',
                timer: 1500,
                showConfirmButton: false,
                background: '#172d1a',
                color: '#e8f5e9'
            });
        });
    });
})();
</script>
</body>
</html>