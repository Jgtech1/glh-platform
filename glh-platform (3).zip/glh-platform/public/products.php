<?php
session_start();
require_once '../classes/Product.php';
require_once '../classes/CurrencyManager.php';

$productObj      = new Product();
$currencyManager = new CurrencyManager();
$currentCurrency = $currencyManager->getCurrentCurrency();

$search   = $_GET['search']   ?? '';
$category = $_GET['category'] ?? '';
$sort     = $_GET['sort']     ?? 'default';

if ($search) {
    $products = $productObj->searchProducts($search);
} else {
    $products = $productObj->getAllProducts();
}

// Client-side sort (keeps it simple without extra DB queries)
if (!empty($products)) {
    usort($products, function($a, $b) use ($sort) {
        $pa = isset($a['price']) ? $a['price'] : (isset($a['base_price']) ? $a['base_price'] : 0);
        $pb = isset($b['price']) ? $b['price'] : (isset($b['base_price']) ? $b['base_price'] : 0);
        switch ($sort) {
            case 'price_asc':  return $pa <=> $pb;
            case 'price_desc': return $pb <=> $pa;
            case 'name_asc':   return strcasecmp($a['name'], $b['name']);
            case 'name_desc':  return strcasecmp($b['name'], $a['name']);
            default:           return 0;
        }
    });
}

$totalProducts  = count($products);
$inStockCount   = count(array_filter($products, fn($p) => ($p['stock_quantity'] ?? 0) > 0));
?>
<!DOCTYPE html>
<html lang="en" data-theme="default">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $search ? 'Search: ' . htmlspecialchars($search) . ' — ' : ''; ?>Products — Greenfield Local Hub</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

        <link href="assets/css/style.css" rel="stylesheet">

</head>
<body>

<a class="skip-link" href="#main-content">Skip to main content</a>

<!-- A11y toolbar -->
<div class="a11y-toolbar" role="toolbar" aria-label="Accessibility options">
    <div class="container">
        <span class="a11y-label" aria-hidden="true"><i class="fas fa-universal-access"></i> Accessibility:</span>
        <button class="a11y-btn" id="btn-theme-dark"  aria-pressed="false" title="Toggle dark mode"><i class="fas fa-moon" aria-hidden="true"></i> Dark</button>
        <div class="a11y-divider" role="separator" aria-hidden="true"></div>
        <button class="a11y-btn" id="btn-theme-high"  aria-pressed="false" title="High contrast"><i class="fas fa-adjust" aria-hidden="true"></i> High Contrast</button>
        <button class="a11y-btn" id="btn-theme-low"   aria-pressed="false" title="Low contrast"><i class="fas fa-circle-half-stroke" aria-hidden="true"></i> Low Contrast</button>
        <div class="a11y-divider" role="separator" aria-hidden="true"></div>
        <button class="a11y-btn" id="btn-font-large"  aria-pressed="false" title="Large text"><i class="fas fa-text-height" aria-hidden="true"></i> Large Text</button>
        <button class="a11y-btn" id="btn-reset"        title="Reset appearance"><i class="fas fa-rotate-left" aria-hidden="true"></i> Reset</button>
    </div>
</div>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg" aria-label="Main navigation">
    <div class="container">
        <a class="navbar-brand" href="index.php" aria-label="Greenfield Local Hub home">
            <div class="brand-leaf" aria-hidden="true"><i class="fas fa-seedling"></i></div>
            Greenfield Local Hub
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarNav" aria-controls="navbarNav"
                aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto" role="list">
                <li class="nav-item" role="listitem">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item" role="listitem">
                    <a class="nav-link active" href="products.php" aria-current="page">Products</a>
                </li>
            </ul>

            <!-- Search form -->
            <form class="d-flex me-3" method="GET" action="products.php" role="search" aria-label="Search products">
                <input class="search-input" type="search" name="search"
                       placeholder="Search products…"
                       value="<?php echo htmlspecialchars($search); ?>"
                       aria-label="Search products">
                <button class="search-btn" type="submit" aria-label="Submit search">
                    <i class="fas fa-search" aria-hidden="true"></i>
                </button>
            </form>

            <ul class="navbar-nav" role="list">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <li class="nav-item" role="listitem">
                        <a class="nav-link" href="logout.php">
                            <i class="fas fa-sign-out-alt" aria-hidden="true"></i>
                            Logout <span style="color:var(--accent-bright)">(<?php echo htmlspecialchars($_SESSION['username']); ?>)</span>
                        </a>
                    </li>
                    <?php if ($_SESSION['role'] == 'customer'): ?>
                    <li class="nav-item" role="listitem">
                        <a class="nav-link cart-wrapper" href="cart.php" aria-label="Shopping cart">
                            <i class="fas fa-shopping-cart" aria-hidden="true"></i> Cart
                            <span id="cartCount" class="cart-badge" aria-live="polite" aria-label="0 items">0</span>
                        </a>
                    </li>
                    <?php endif; ?>
                <?php else: ?>
                    <li class="nav-item" role="listitem"><a class="nav-link" href="login.php">Login</a></li>
                    <li class="nav-item" role="listitem"><a class="nav-link" href="register.php">Register</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<!-- Page hero -->
<div class="page-hero" role="banner">
    <div class="container">
        <h1>
            <?php if ($search): ?>
                Results for <span>"<?php echo htmlspecialchars($search); ?>"</span>
            <?php else: ?>
                All <span>Products</span>
            <?php endif; ?>
        </h1>
        <p>
            <?php if ($search): ?>
                Showing matches from our local farmers
            <?php else: ?>
                Fresh produce from verified local farms, harvested daily
            <?php endif; ?>
        </p>
        <div class="stats-row" aria-label="Catalogue summary">
            <div class="stat-pill"><i class="fas fa-box" aria-hidden="true"></i> <?php echo $totalProducts; ?> product<?php echo $totalProducts !== 1 ? 's' : ''; ?></div>
            <div class="stat-pill"><i class="fas fa-check-circle" aria-hidden="true"></i> <?php echo $inStockCount; ?> in stock</div>
            <?php if ($search): ?>
            <div class="stat-pill">
                <i class="fas fa-search" aria-hidden="true"></i>
                Searching: "<?php echo htmlspecialchars($search); ?>"
                <a href="products.php" style="color:var(--accent-gold);margin-left:4px;text-decoration:none" aria-label="Clear search">✕</a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Filter / sort bar -->
<div class="filter-bar" role="toolbar" aria-label="Sort and filter options">
    <div class="container">
        <p class="result-count" aria-live="polite">
            Showing <strong><?php echo $totalProducts; ?></strong> result<?php echo $totalProducts !== 1 ? 's' : ''; ?>
        </p>
        <form method="GET" action="products.php" id="sortForm" style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
            <?php if ($search): ?>
                <input type="hidden" name="search" value="<?php echo htmlspecialchars($search); ?>">
            <?php endif; ?>
            <span class="filter-label" id="sort-label">Sort by:</span>
            <select class="filter-select" name="sort" aria-labelledby="sort-label"
                    onchange="this.form.submit()">
                <option value="default"    <?php echo $sort === 'default'    ? 'selected' : ''; ?>>Default</option>
                <option value="price_asc"  <?php echo $sort === 'price_asc'  ? 'selected' : ''; ?>>Price: Low → High</option>
                <option value="price_desc" <?php echo $sort === 'price_desc' ? 'selected' : ''; ?>>Price: High → Low</option>
                <option value="name_asc"   <?php echo $sort === 'name_asc'   ? 'selected' : ''; ?>>Name: A → Z</option>
                <option value="name_desc"  <?php echo $sort === 'name_desc'  ? 'selected' : ''; ?>>Name: Z → A</option>
            </select>
        </form>
    </div>
</div>

<!-- Products grid -->
<main id="main-content" class="products-section">
    <div class="container">
        <?php if (empty($products)): ?>
            <div class="empty-state" role="status">
                <div class="empty-icon" aria-hidden="true"><i class="fas fa-seedling"></i></div>
                <h3><?php echo $search ? 'No results found' : 'No products yet'; ?></h3>
                <p>
                    <?php if ($search): ?>
                        Nothing matched "<?php echo htmlspecialchars($search); ?>". Try a different term.
                    <?php else: ?>
                        Check back soon — local farmers update their listings daily!
                    <?php endif; ?>
                </p>
                <?php if ($search): ?>
                <a href="products.php" class="btn-clear-search">
                    <i class="fas fa-times" aria-hidden="true"></i> Clear Search
                </a>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="row g-4" aria-label="Product listings" aria-live="polite">
                <?php foreach ($products as $product):
                    $price       = isset($product['price']) ? $product['price'] : (isset($product['base_price']) ? $product['base_price'] : 0);
                    $converted   = $currencyManager->convert($price);
                    $formatted   = $currencyManager->formatPrice($converted);
                    $imagePath   = !empty($product['image_url']) ? '../public/' . $product['image_url'] : 'assets/images/default-product.jpg';
                    $stock       = (int)($product['stock_quantity'] ?? 0);
                    $stockClass  = $stock <= 0 ? '' : ($stock <= 5 ? 'low' : ($stock <= 20 ? 'medium' : 'high'));
                    $inStock     = $stock > 0;
                ?>
                <div class="col-sm-6 col-lg-4">
                    <article class="product-card<?php echo !$inStock ? ' out-of-stock' : ''; ?>"
                             aria-label="<?php echo htmlspecialchars($product['name']); ?>">
                        <div class="card-img-wrap">
                            <img src="<?php echo htmlspecialchars($imagePath); ?>"
                                 alt="<?php echo htmlspecialchars($product['name']); ?>"
                                 loading="lazy"
                                 onerror="this.src='assets/images/default-product.jpg'">
                            <?php if ($inStock): ?>
                                <span class="badge-fresh" aria-label="In stock">Fresh</span>
                            <?php else: ?>
                                <span class="badge-sold-out" aria-label="Out of stock">Sold Out</span>
                            <?php endif; ?>
                        </div>

                        <div class="card-body">
                            <h2 class="card-title"><?php echo htmlspecialchars($product['name']); ?></h2>
                            <p class="card-desc">
                                <?php
                                $desc = $product['description'] ?? '';
                                echo htmlspecialchars(strlen($desc) > 95 ? substr($desc, 0, 95) . '…' : $desc);
                                ?>
                            </p>

                            <div class="price-row">
                                <span class="price"><?php echo $formatted; ?></span>
                                <span class="unit">/ <?php echo htmlspecialchars($product['unit'] ?? 'item'); ?></span>
                            </div>

                            <div class="meta-row">
                                <span>
                                    <?php if ($inStock): ?>
                                        <span class="stock-dot <?php echo $stockClass; ?>" aria-hidden="true"></span>
                                        <?php echo $stock; ?> unit<?php echo $stock !== 1 ? 's' : ''; ?> left
                                    <?php else: ?>
                                        <i class="fas fa-times-circle" style="color:#ef9a9a" aria-hidden="true"></i>
                                        Out of stock
                                    <?php endif; ?>
                                </span>
                                <span><i class="fas fa-user-tie" aria-hidden="true"></i> <?php echo htmlspecialchars($product['producer_name']); ?></span>
                            </div>

                            <div class="card-actions">
                                <?php if (isset($_SESSION['user_id']) && $_SESSION['role'] == 'customer' && $inStock): ?>
                                <button class="btn-add-cart add-to-cart"
                                        data-product-id="<?php echo (int)$product['id']; ?>"
                                        aria-label="Add <?php echo htmlspecialchars($product['name']); ?> to cart">
                                    <i class="fas fa-cart-plus" aria-hidden="true"></i> Add to Cart
                                </button>
                                <?php elseif (!$inStock): ?>
                                <button class="btn-add-cart" disabled aria-disabled="true">
                                    <i class="fas fa-ban" aria-hidden="true"></i> Unavailable
                                </button>
                                <?php endif; ?>
                                <a href="product-details.php?id=<?php echo (int)$product['id']; ?>"
                                   class="btn-details"
                                   aria-label="View details for <?php echo htmlspecialchars($product['name']); ?>">
                                    <i class="fas fa-eye" aria-hidden="true"></i> Details
                                </a>
                            </div>
                        </div>
                    </article>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</main>

<!-- Footer -->
<footer role="contentinfo">
    <div class="container">
        <p>&copy; 2024 <a href="index.php">Greenfield Local Hub</a>. Fresh from local farms to your table.</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function () {
    'use strict';

    /* ---- A11y theme engine ---- */
    var html      = document.documentElement;
    var THEME_KEY = 'glh_theme';
    var FONT_KEY  = 'glh_font';

    function applyTheme(theme) {
        html.setAttribute('data-theme', theme || 'default');
        ['dark','high','low'].forEach(function(t) {
            var b = document.getElementById('btn-theme-' + t);
            if (b) { b.classList.remove('active'); b.setAttribute('aria-pressed','false'); }
        });
        var map = { dark:'btn-theme-dark', 'high-contrast':'btn-theme-high', 'low-contrast':'btn-theme-low' };
        if (map[theme]) {
            var el = document.getElementById(map[theme]);
            if (el) { el.classList.add('active'); el.setAttribute('aria-pressed','true'); }
        }
        localStorage.setItem(THEME_KEY, theme || 'default');
    }
    function toggleTheme(t) { applyTheme(html.getAttribute('data-theme') === t ? 'default' : t); }

    function applyFont(size) {
        html.setAttribute('data-font-size', size || 'normal');
        var btn = document.getElementById('btn-font-large');
        var lg  = size === 'large';
        btn.classList.toggle('active', lg);
        btn.setAttribute('aria-pressed', lg ? 'true' : 'false');
        localStorage.setItem(FONT_KEY, size || 'normal');
    }

    var st = localStorage.getItem(THEME_KEY);
    var sf = localStorage.getItem(FONT_KEY);
    if (st) applyTheme(st);
    if (sf) applyFont(sf);

    document.getElementById('btn-theme-dark').addEventListener('click', function(){ toggleTheme('dark'); });
    document.getElementById('btn-theme-high').addEventListener('click', function(){ toggleTheme('high-contrast'); });
    document.getElementById('btn-theme-low').addEventListener('click',  function(){ toggleTheme('low-contrast'); });
    document.getElementById('btn-font-large').addEventListener('click', function(){ applyFont(html.getAttribute('data-font-size') === 'large' ? 'normal' : 'large'); });
    document.getElementById('btn-reset').addEventListener('click', function(){ applyTheme('default'); applyFont('normal'); });

    /* ---- Cart count ---- */
    function loadCartCount() {
        $.ajax({
            url: '../ajax/load-cart-count.php',
            method: 'GET',
            success: function(response) {
                var count = parseInt(response) || 0;
                var badge = document.getElementById('cartCount');
                if (badge) {
                    badge.textContent = count;
                    badge.setAttribute('aria-label', count + ' item' + (count !== 1 ? 's' : '') + ' in cart');
                }
            }
        });
    }
    <?php if (isset($_SESSION['user_id']) && $_SESSION['role'] == 'customer'): ?>
    loadCartCount();
    <?php endif; ?>

    /* ---- Add to cart ---- */
    document.querySelectorAll('.add-to-cart').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var productId   = this.dataset.productId;
            var origHTML    = this.innerHTML;
            this.disabled   = true;
            this.innerHTML  = '<i class="fas fa-spinner fa-spin" aria-hidden="true"></i> Adding…';
            var self = this;

            $.ajax({
                url: '../ajax/add-to-cart.php',
                method: 'POST',
                data: { product_id: productId, quantity: 1 },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        Swal.fire({
                            icon: 'success', title: 'Added to Cart!',
                            text: 'Product added successfully.',
                            timer: 1500, showConfirmButton: false,
                            background: '#172d1a', color: '#e8f5e9', iconColor: '#4caf50'
                        });
                        loadCartCount();
                    } else {
                        Swal.fire({
                            icon: 'error', title: 'Error',
                            text: response.message || 'Failed to add to cart.',
                            background: '#172d1a', color: '#e8f5e9', confirmButtonColor: '#2e7d32'
                        });
                    }
                },
                error: function() {
                    Swal.fire({
                        icon: 'error', title: 'Error',
                        text: 'An error occurred. Please try again.',
                        background: '#172d1a', color: '#e8f5e9', confirmButtonColor: '#2e7d32'
                    });
                },
                complete: function() {
                    self.disabled  = false;
                    self.innerHTML = origHTML;
                }
            });
        });
    });
})();
</script>
</body>
</html>