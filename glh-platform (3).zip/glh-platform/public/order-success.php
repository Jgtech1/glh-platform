<?php
session_start();
require_once '../classes/User.php';
require_once '../classes/Order.php';
require_once '../classes/ContentManager.php';
require_once '../classes/CurrencyManager.php';

$userObj        = new User();
$orderObj       = new Order();
$contentManager = new ContentManager();
$currencyManager = new CurrencyManager();

// Redirect if not logged in
if (!$userObj->isLoggedIn()) {
    header('Location: login.php');
    exit;
}

// Get order ID from URL
$orderId = isset($_GET['order_id']) ? (int) $_GET['order_id'] : 0;
if ($orderId <= 0) {
    header('Location: index.php');
    exit;
}

// Get order details
$order = $orderObj->getOrderById($orderId);

// Verify order belongs to the logged-in user
if (!$order || (int) $order['user_id'] !== (int) $_SESSION['user_id']) {
    header('Location: index.php');
    exit;
}

// Get order items
$orderItems = $orderObj->getOrderItems($orderId);

// Get current currency
$currentCurrency = $currencyManager->getCurrentCurrency();
$symbol          = $currentCurrency['currency_symbol'] ?? '$';

// FIX: getOrderItems() returns 'unit_price_display' (aliased from price_at_time),
// NOT 'price_at_time_display'. Normalise every item to a single 'unit_price' key.
foreach ($orderItems as &$item) {
    $item['unit_price'] = (float) (
        $item['unit_price_display']    // alias set in getOrderItems()
        ?? $item['price_at_time']      // raw column fallback
        ?? 0
    );
}
unset($item);

// Calculate subtotal from normalised unit_price
$subtotal = 0;
foreach ($orderItems as $item) {
    $subtotal += $item['unit_price'] * (int) $item['quantity'];
}

$shippingCost = 5.00;
$taxAmount    = $subtotal * 0.08;

// FIX: use total_amount_display if available, else fall back to total_amount
$totalAmount = (float) (
    $order['total_amount_display']
    ?? $order['total_amount']
    ?? ($subtotal + $shippingCost + $taxAmount)
);

// Loyalty points info
$loyaltyPointsUsed   = (int)   ($order['loyalty_points_used']   ?? 0);
$loyaltyPointsEarned = (int)   ($order['loyalty_points_earned'] ?? 0);
$loyaltyDiscount     = $orderObj->calculatePointsDiscount($loyaltyPointsUsed);

// Estimated delivery (3–5 business days)
$orderDate       = new DateTime($order['created_at']);
$deliveryStart   = clone $orderDate; $deliveryStart->modify('+3 days');
$deliveryEnd     = clone $orderDate; $deliveryEnd->modify('+5 days');

$siteTitle = $contentManager->get('site_title', 'Greenfield Local Hub');
?>
<!DOCTYPE html>
<html lang="en" data-theme="default">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmed | <?php echo htmlspecialchars($siteTitle); ?></title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

       <link href="assets/css/style.css" rel="stylesheet">

</head>
<body>

<a class="skip-link" href="#main-content">Skip to main content</a>

<?php if ($contentManager->get('promo_banner')): ?>
<div style="background:var(--promo-bg);color:var(--text-inverse);text-align:center;padding:10px 1rem;font-size:.9rem;font-weight:600;">
    <i class="fas fa-tag"></i> <?php echo $contentManager->render('promo_banner'); ?>
</div>
<?php endif; ?>

<!-- Accessibility toolbar -->
<div class="a11y-toolbar">
    <div class="container">
        <span class="a11y-label"><i class="fas fa-universal-access"></i> Accessibility:</span>
        <button class="a11y-btn" id="btn-theme-dark"><i class="fas fa-moon"></i> Dark</button>
        <div class="a11y-divider"></div>
        <button class="a11y-btn" id="btn-theme-high"><i class="fas fa-adjust"></i> High Contrast</button>
        <button class="a11y-btn" id="btn-theme-low"><i class="fas fa-circle-half-stroke"></i> Low Contrast</button>
        <div class="a11y-divider"></div>
        <button class="a11y-btn" id="btn-font-large"><i class="fas fa-text-height"></i> Large Text</button>
        <button class="a11y-btn" id="btn-reset"><i class="fas fa-rotate-left"></i> Reset</button>
    </div>
</div>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="index.php">
            <div class="brand-leaf"><i class="fas fa-seedling"></i></div>
            <?php echo htmlspecialchars($siteTitle); ?>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto align-items-center">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="products.php">Products</a></li>
                <li class="nav-item"><a class="nav-link" href="order-history.php">My Orders</a></li>
                <li class="nav-item"><a class="nav-link" href="cart.php"><i class="fas fa-shopping-cart"></i> Cart</a></li>
                <li class="nav-item"><a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                <li class="nav-item dropdown">
                    <button class="nav-link dropdown-toggle btn btn-link border-0" id="currencyDropdown" data-bs-toggle="dropdown">
                        <?php echo htmlspecialchars($currentCurrency['currency_symbol']); ?>
                        <?php echo htmlspecialchars($currentCurrency['currency_code']); ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <?php foreach ($currencyManager->getAllCurrencies() as $currency): ?>
                        <li>
                            <button class="dropdown-item currency-option"
                                    data-currency="<?php echo htmlspecialchars($currency['currency_code']); ?>">
                                <?php echo htmlspecialchars($currency['currency_symbol']); ?>
                                <?php echo htmlspecialchars($currency['currency_code']); ?>
                            </button>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Breadcrumb -->
<div class="breadcrumb-wrapper">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item"><a href="order-history.php">My Orders</a></li>
                <li class="breadcrumb-item active" aria-current="page">Order Confirmed</li>
            </ol>
        </nav>
    </div>
</div>

<!-- ===== MAIN ===== -->
<main id="main-content">
<section class="success-section">
<div class="container">

    <!-- Success hero -->
    <div class="info-card slide-up">
        <div class="success-hero">
            <div class="success-icon-ring" role="img" aria-label="Order confirmed">
                <i class="fas fa-check"></i>
            </div>
            <h1>Thank You for Your Order!</h1>
            <p style="color:var(--text-muted);">Your order has been placed and is being prepared.</p>
            <div class="order-badge">
                <i class="fas fa-receipt"></i>
                <?php echo htmlspecialchars($order['order_number'] ?? ('ORD-' . str_pad($order['id'], 6, '0', STR_PAD_LEFT))); ?>
            </div>
        </div>

        <!-- Stat pills -->
        <div class="stat-grid">
            <div class="stat-pill">
                <div class="stat-pill-icon"><i class="fas fa-calendar-check"></i></div>
                <div>
                    <div class="stat-pill-label">Order Date</div>
                    <div class="stat-pill-value"><?php echo date('M j, Y \a\t g:i A', strtotime($order['created_at'])); ?></div>
                </div>
            </div>
            <div class="stat-pill">
                <div class="stat-pill-icon"><i class="fas fa-truck"></i></div>
                <div>
                    <div class="stat-pill-label">Estimated Delivery</div>
                    <div class="stat-pill-value"><?php echo $deliveryStart->format('M j') . ' – ' . $deliveryEnd->format('M j, Y'); ?></div>
                </div>
            </div>
            <div class="stat-pill">
                <div class="stat-pill-icon"><i class="fas fa-money-bill-wave"></i></div>
                <div>
                    <div class="stat-pill-label">Payment</div>
                    <div class="stat-pill-value">
                        <?php
                        $pm = $order['payment_method'] ?? 'cod';
                        $pmLabels = ['cod' => 'Cash on Delivery', 'card' => 'Card', 'paypal' => 'PayPal'];
                        echo htmlspecialchars($pmLabels[$pm] ?? ucfirst($pm));
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4 mt-1">

        <!-- ===== LEFT: Items + address ===== -->
        <div class="col-lg-7">

            <!-- Order items -->
            <div class="info-card slide-up slide-up-1">
                <div class="info-card-title">
                    <i class="fas fa-box-open"></i> Order Items
                </div>
                <?php foreach ($orderItems as $item):
                    $hasImage = !empty($item['image_url']);
                    $imgSrc   = $hasImage
                        ? (strpos($item['image_url'], 'http') === 0
                            ? $item['image_url']
                            : '../' . ltrim($item['image_url'], '/'))
                        : null;
                    $lineTotal = $item['unit_price'] * (int) $item['quantity'];
                ?>
                <div class="order-item">
                    <?php if ($imgSrc): ?>
                        <img src="<?php echo htmlspecialchars($imgSrc); ?>"
                             alt="<?php echo htmlspecialchars($item['name']); ?>"
                             class="order-item-img"
                             onerror="this.onerror=null;this.style.display='none';this.nextElementSibling.style.display='flex';">
                        <div class="order-item-placeholder" style="display:none;"><i class="fas fa-leaf"></i></div>
                    <?php else: ?>
                        <div class="order-item-placeholder"><i class="fas fa-leaf"></i></div>
                    <?php endif; ?>

                    <div class="order-item-details">
                        <div class="order-item-name"><?php echo htmlspecialchars($item['name']); ?></div>
                        <div class="order-item-meta">
                            Qty: <?php echo (int) $item['quantity']; ?>
                            &nbsp;·&nbsp;
                            <?php echo htmlspecialchars($symbol) . number_format($item['unit_price'], 2); ?> each
                            <?php if (!empty($item['unit'])): ?>
                                &nbsp;·&nbsp;<?php echo htmlspecialchars($item['unit']); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="order-item-price">
                        <?php echo htmlspecialchars($symbol) . number_format($lineTotal, 2); ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Shipping address -->
            <div class="info-card mt-4 slide-up slide-up-2">
                <div class="info-card-title">
                    <i class="fas fa-map-marker-alt"></i> Shipping Address
                </div>
                <div class="address-block">
                    <?php echo nl2br(htmlspecialchars($order['delivery_address'] ?? 'Address not specified')); ?>
                </div>
            </div>

        </div><!-- /col-lg-7 -->

        <!-- ===== RIGHT: Summary ===== -->
        <div class="col-lg-5">
            <div class="info-card slide-up slide-up-2">
                <div class="info-card-title">
                    <i class="fas fa-receipt"></i> Order Summary
                </div>

                <div class="summary-row">
                    <span>Subtotal</span>
                    <span><?php echo htmlspecialchars($symbol) . number_format($subtotal, 2); ?></span>
                </div>
                <div class="summary-row">
                    <span>Shipping</span>
                    <span><?php echo htmlspecialchars($symbol) . number_format($shippingCost, 2); ?></span>
                </div>
                <div class="summary-row">
                    <span>Tax (8%)</span>
                    <span><?php echo htmlspecialchars($symbol) . number_format($taxAmount, 2); ?></span>
                </div>

                <?php if ($loyaltyPointsUsed > 0): ?>
                <div class="summary-row discount-row">
                    <span><i class="fas fa-star"></i> Loyalty Discount</span>
                    <span>-<?php echo htmlspecialchars($symbol) . number_format($loyaltyDiscount, 2); ?></span>
                </div>
                <?php endif; ?>

                <div class="summary-total">
                    <span>Total</span>
                    <span><?php echo htmlspecialchars($symbol) . number_format($totalAmount, 2); ?></span>
                </div>

                <!-- Loyalty earned notice -->
                <?php if ($loyaltyPointsEarned > 0): ?>
                <div class="loyalty-earned">
                    <i class="fas fa-star"></i>
                    <div class="loyalty-earned-text">
                        <strong>+<?php echo number_format($loyaltyPointsEarned); ?> loyalty points earned!</strong>
                        <small>Points have been added to your account and can be used on your next order.</small>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Order status badge -->
                <div class="text-center mt-3">
                    <span style="background:rgba(76,175,80,.12);border:1px solid var(--accent-primary);
                                 color:var(--accent-bright);border-radius:50px;padding:.35rem 1rem;
                                 font-size:.8rem;font-weight:700;text-transform:uppercase;letter-spacing:.05em;">
                        <i class="fas fa-circle" style="font-size:.5rem;vertical-align:middle;"></i>
                        <?php echo ucfirst(htmlspecialchars($order['status'] ?? 'pending')); ?>
                    </span>
                </div>
            </div>

            <!-- Action buttons -->
            <div class="info-card mt-4 slide-up slide-up-3" style="text-align:center;">
                <div class="info-card-title" style="justify-content:center;">
                    <i class="fas fa-arrow-right"></i> What's Next?
                </div>
                <p style="font-size:.85rem;color:var(--text-muted);margin-bottom:1.25rem;">
                    We'll prepare your order and deliver it within the estimated window. You can track it from your orders page.
                </p>
                <div class="d-flex flex-column gap-2">
                    <a href="order-history.php" class="btn-success-primary justify-content-center">
                        <i class="fas fa-list-ul"></i> View All Orders
                    </a>
                    <a href="products.php" class="btn-success-outline justify-content-center">
                        <i class="fas fa-shopping-bag"></i> Continue Shopping
                    </a>
                </div>
                <p style="font-size:.75rem;color:var(--text-muted);margin-top:1.25rem;margin-bottom:0;">
                    <i class="fas fa-envelope"></i>
                    A confirmation has been sent to your registered email address.
                </p>
            </div>

        </div><!-- /col-lg-5 -->
    </div><!-- /row -->

</div><!-- /container -->
</section>
</main>

<!-- Footer -->
<footer>
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-4 col-md-6">
                <div class="footer-brand"><i class="fas fa-seedling"></i> <?php echo htmlspecialchars($siteTitle); ?></div>
                <p class="footer-desc">Fresh from local farms to your table.</p>
            </div>
            <div class="col-lg-2 col-md-6 col-6">
                <p class="footer-heading">Navigate</p>
                <a href="index.php" class="footer-link">Home</a>
                <a href="products.php" class="footer-link">Products</a>
            </div>
            <div class="col-lg-2 col-md-6 col-6">
                <p class="footer-heading">Account</p>
                <a href="order-history.php" class="footer-link">Orders</a>
                <a href="cart.php" class="footer-link">Cart</a>
            </div>
            <div class="col-lg-4 col-md-6">
                <p class="footer-heading">Contact</p>
                <a href="mailto:support@greenfieldhub.com" class="footer-link">support@greenfieldhub.com</a>
            </div>
        </div>
        <hr class="footer-divider">
        <p class="footer-copy">&copy; 2024 <?php echo htmlspecialchars($siteTitle); ?>. All rights reserved.</p>
    </div>
</footer>

<!-- Confetti canvas -->
<canvas id="confettiCanvas" style="position:fixed;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:9999;"></canvas>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function () {
    // ── Theme / font persistence (identical to checkout.php) ──
    const html      = document.documentElement;
    const THEME_KEY = 'glh_theme';
    const FONT_KEY  = 'glh_font';

    function applyTheme(t) { html.setAttribute('data-theme', t || 'default'); localStorage.setItem(THEME_KEY, t || 'default'); }
    function applyFont(s)  { html.setAttribute('data-font-size', s || 'normal'); localStorage.setItem(FONT_KEY, s || 'normal'); }

    const savedTheme = localStorage.getItem(THEME_KEY);
    const savedFont  = localStorage.getItem(FONT_KEY);
    if (savedTheme) applyTheme(savedTheme);
    if (savedFont)  applyFont(savedFont);

    document.getElementById('btn-theme-dark')?.addEventListener('click', () => applyTheme(html.getAttribute('data-theme') === 'dark' ? 'default' : 'dark'));
    document.getElementById('btn-theme-high')?.addEventListener('click', () => applyTheme(html.getAttribute('data-theme') === 'high-contrast' ? 'default' : 'high-contrast'));
    document.getElementById('btn-theme-low')?.addEventListener('click',  () => applyTheme(html.getAttribute('data-theme') === 'low-contrast'  ? 'default' : 'low-contrast'));
    document.getElementById('btn-font-large')?.addEventListener('click', () => applyFont(html.getAttribute('data-font-size') === 'large' ? 'normal' : 'large'));
    document.getElementById('btn-reset')?.addEventListener('click', () => { applyTheme('default'); applyFont('normal'); });

    // ── Currency switcher ──
    document.querySelectorAll('.currency-option').forEach(el => {
        el.addEventListener('click', function () {
            fetch('set-currency.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'currency=' + encodeURIComponent(this.dataset.currency)
            })
            .then(r => r.json())
            .then(r => { if (r.success) location.reload(); });
        });
    });

    // ── Confetti ──
    const canvas = document.getElementById('confettiCanvas');
    const ctx    = canvas.getContext('2d');
    canvas.width  = window.innerWidth;
    canvas.height = window.innerHeight;

    const colors  = ['#4caf50','#81c784','#ffd54f','#a5d6a7','#ffffff','#66bb6a'];
    const pieces  = [];
    const COUNT   = 80;

    for (let i = 0; i < COUNT; i++) {
        pieces.push({
            x:     Math.random() * canvas.width,
            y:     Math.random() * -canvas.height,
            w:     6 + Math.random() * 8,
            h:     10 + Math.random() * 6,
            color: colors[Math.floor(Math.random() * colors.length)],
            speed: 2 + Math.random() * 3,
            angle: Math.random() * Math.PI * 2,
            spin:  (Math.random() - .5) * .12,
            drift: (Math.random() - .5) * 1.2,
            opacity: 1,
        });
    }

    let frame = 0;
    function draw() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        let alive = false;
        pieces.forEach(p => {
            p.y     += p.speed;
            p.x     += p.drift;
            p.angle += p.spin;
            if (p.y > canvas.height * .8) p.opacity -= .015;
            if (p.opacity <= 0) return;
            alive = true;
            ctx.save();
            ctx.globalAlpha = Math.max(0, p.opacity);
            ctx.translate(p.x, p.y);
            ctx.rotate(p.angle);
            ctx.fillStyle = p.color;
            ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
            ctx.restore();
        });
        if (alive) requestAnimationFrame(draw);
        else canvas.remove();
    }
    requestAnimationFrame(draw);
    window.addEventListener('resize', () => {
        canvas.width  = window.innerWidth;
        canvas.height = window.innerHeight;
    });
})();
</script>
</body>
</html>